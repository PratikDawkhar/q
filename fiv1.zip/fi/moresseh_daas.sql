-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 26, 2026 at 09:48 AM
-- Server version: 8.0.18
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `moresseh_daas`
--

-- --------------------------------------------------------

--
-- Table structure for table `action`
--

CREATE TABLE `action` (
  `action_seq` int(11) NOT NULL,
  `action_name` varchar(100) DEFAULT NULL,
  `active_flag` varchar(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `all_modbus_run`
--

CREATE TABLE `all_modbus_run` (
  `id` int(10) NOT NULL,
  `modbus_run_status` int(10) DEFAULT NULL,
  `date_time` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `ip` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `app_parm`
--

CREATE TABLE `app_parm` (
  `parm_seq` int(11) NOT NULL,
  `parm_desc` varchar(50) DEFAULT NULL,
  `modbusadress` int(11) DEFAULT NULL,
  `modbus_length` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `backup_setting`
--

CREATE TABLE `backup_setting` (
  `backup_cd` int(11) NOT NULL,
  `backup_type` varchar(10) NOT NULL,
  `back_date` datetime DEFAULT NULL,
  `week_day` varchar(10) DEFAULT NULL,
  `backup_location` varchar(200) NOT NULL,
  `user_id` int(11) NOT NULL,
  `backup_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `backup_setting_log`
--

CREATE TABLE `backup_setting_log` (
  `backup_cd` int(11) NOT NULL,
  `backup_type` varchar(10) NOT NULL,
  `back_date` datetime DEFAULT NULL,
  `week_day` varchar(10) DEFAULT NULL,
  `backup_location` varchar(200) NOT NULL,
  `user_id` int(11) NOT NULL,
  `backup_time` time NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `action` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `chamber_component`
--

CREATE TABLE `chamber_component` (
  `chamber_component_seq` int(11) NOT NULL,
  `chamber_seq` decimal(10,0) DEFAULT NULL,
  `input_comp` text,
  `output_comp` text,
  `user_id` int(11) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `chamber_event`
--

CREATE TABLE `chamber_event` (
  `chamber_event_seq` int(11) NOT NULL,
  `event_cd` varchar(10) NOT NULL,
  `chamber_seq` decimal(10,0) NOT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `sms` varchar(1) DEFAULT NULL,
  `email` varchar(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `chamber_master`
--

CREATE TABLE `chamber_master` (
  `chamber_seq` decimal(10,0) NOT NULL,
  `Master_Device_cd` decimal(10,0) DEFAULT NULL,
  `Scanner_Device_cd` decimal(10,0) DEFAULT NULL,
  `Chamber_cd` varchar(20) NOT NULL,
  `Chamber_Name` varchar(50) NOT NULL,
  `Chamber_description` varchar(250) DEFAULT NULL,
  `temp_low_limit` decimal(5,2) DEFAULT NULL,
  `temp_upper_limit` decimal(5,2) DEFAULT NULL,
  `humidity_low_limit` decimal(5,2) DEFAULT NULL,
  `humidity_upper_limit` decimal(5,2) DEFAULT NULL,
  `chamber_user_id` varchar(20) DEFAULT NULL,
  `channel_type` varchar(1) DEFAULT NULL,
  `ip_address` varchar(15) DEFAULT NULL,
  `topic` varchar(50) DEFAULT NULL,
  `active_flg` varchar(1) DEFAULT NULL,
  `report_type` varchar(5) DEFAULT NULL,
  `no_of_temp_channel` decimal(5,0) DEFAULT NULL,
  `no_of_humidity_channel` decimal(5,0) DEFAULT NULL,
  `lux_uv` varchar(1) DEFAULT NULL,
  `Serial_no` varchar(100) DEFAULT NULL,
  `Model_no` varchar(100) DEFAULT NULL,
  `BioMetric_IPAdrr_Outside` varchar(200) DEFAULT NULL,
  `BioMetric_IPAdrr_InSide` varchar(200) DEFAULT NULL,
  `hmi_type` varchar(10) DEFAULT NULL,
  `hmi_ip_address` varchar(100) DEFAULT NULL,
  `lux_uvB` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `chamber_master_log`
--

CREATE TABLE `chamber_master_log` (
  `Chamber_Master_Log_Seq` int(11) NOT NULL,
  `Master_Device_cd` decimal(10,0) DEFAULT NULL,
  `Scanner_Device_cd` decimal(10,0) DEFAULT NULL,
  `Chamber_cd` varchar(20) NOT NULL,
  `Chamber_Name` varchar(50) NOT NULL,
  `Chamber_description` varchar(250) DEFAULT NULL,
  `temp_low_limit` decimal(5,2) DEFAULT NULL,
  `temp_upper_limit` decimal(5,2) DEFAULT NULL,
  `humidity_low_limit` decimal(5,2) DEFAULT NULL,
  `humidity_upper_limit` decimal(5,2) DEFAULT NULL,
  `plc_seq` decimal(10,0) DEFAULT NULL,
  `chamber_user_id` varchar(20) DEFAULT NULL,
  `chamber_seq` decimal(10,0) NOT NULL,
  `Date_Time` datetime DEFAULT NULL,
  `action` varchar(10) DEFAULT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `active_flg` varchar(3) DEFAULT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `topic` varchar(15) DEFAULT NULL,
  `channel_type` varchar(1) DEFAULT NULL,
  `report_type` varchar(5) DEFAULT NULL,
  `no_of_temp_channel` decimal(5,0) DEFAULT NULL,
  `no_of_humidity_channel` decimal(5,0) DEFAULT NULL,
  `lux_uv` varchar(3) DEFAULT NULL,
  `Serial_no` varchar(100) DEFAULT NULL,
  `Model_no` varchar(100) DEFAULT NULL,
  `BioMetric_IPAdrr_Outside` varchar(200) DEFAULT NULL,
  `BioMetric_IPAdrr_InSide` varchar(200) DEFAULT NULL,
  `hmi_type` int(11) DEFAULT NULL,
  `hmi_ip_address` varchar(100) DEFAULT NULL,
  `lux_uvB` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `channel`
--

CREATE TABLE `channel` (
  `Channel_Seq` decimal(10,0) NOT NULL,
  `Channel_No` varchar(10) DEFAULT NULL,
  `channel_name` varchar(50) DEFAULT NULL,
  `temperature_humidity` varchar(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `channel_settings`
--

CREATE TABLE `channel_settings` (
  `channel_setting_seq` int(11) NOT NULL,
  `temp_alarm_band` decimal(10,1) DEFAULT NULL,
  `temp_alert_band` decimal(10,1) DEFAULT NULL,
  `humidity_alarm_band` decimal(10,1) DEFAULT NULL,
  `humidity_alert_band` decimal(10,1) DEFAULT NULL,
  `chamber_seq` decimal(10,0) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `channel_settings_log`
--

CREATE TABLE `channel_settings_log` (
  `Channel_Settings_Log_Seq` int(11) NOT NULL,
  `chamber_seq` decimal(10,0) NOT NULL,
  `channel_setting_seq` decimal(10,0) NOT NULL,
  `temp_alarm_band` decimal(10,1) DEFAULT NULL,
  `temp_alert_band` decimal(10,1) DEFAULT NULL,
  `humidity_alarm_band` decimal(10,1) DEFAULT NULL,
  `humidity_alert_band` decimal(10,1) DEFAULT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `Date_Time` datetime DEFAULT NULL,
  `action` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `close_door_setting_log`
--

CREATE TABLE `close_door_setting_log` (
  `Close_Door_Setting_Log_Seq` int(11) NOT NULL,
  `chamber_seq` decimal(10,0) NOT NULL,
  `close_door_seq` decimal(10,0) NOT NULL,
  `close_door_minute` datetime DEFAULT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `Date_Time` datetime DEFAULT NULL,
  `action` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `compinstall_name`
--

CREATE TABLE `compinstall_name` (
  `compinstall_name_seq` int(11) NOT NULL,
  `company_name` varchar(100) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `component`
--

CREATE TABLE `component` (
  `component-seq` int(11) NOT NULL,
  `component_cd` varchar(10) NOT NULL,
  `component_name` varchar(100) DEFAULT NULL,
  `status_type` varchar(2) DEFAULT NULL,
  `device_type` varchar(1) DEFAULT NULL,
  `register_address` varchar(50) DEFAULT NULL,
  `receipe_no` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `controller_details`
--

CREATE TABLE `controller_details` (
  `Controller_Detail_Seq` int(11) NOT NULL,
  `Temperature_Value` decimal(5,1) DEFAULT NULL,
  `Temperature_SetPoint` decimal(5,1) DEFAULT NULL,
  `Humidity_Value` decimal(5,1) DEFAULT NULL,
  `Humidity_SetPoint` decimal(5,1) DEFAULT NULL,
  `Record_Date_Time` varchar(200) DEFAULT NULL,
  `chamber_seq` decimal(10,0) DEFAULT NULL,
  `print_frequency` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `coutner_record`
--

CREATE TABLE `coutner_record` (
  `counterid` int(11) NOT NULL,
  `chamber_seq` int(11) DEFAULT NULL,
  `ip_add` varchar(200) DEFAULT NULL,
  `StartCount1` int(11) DEFAULT NULL,
  `StartCount2` int(11) DEFAULT NULL,
  `Type` varchar(5) DEFAULT NULL,
  `Last_DateTime` varchar(100) DEFAULT NULL,
  `update_datetime` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cronjob_response`
--

CREATE TABLE `cronjob_response` (
  `cron_sr` varchar(100) NOT NULL DEFAULT '',
  `cronjob_value` varchar(100) DEFAULT NULL,
  `response_time` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `datetimetb`
--

CREATE TABLE `datetimetb` (
  `datetimeseq` int(11) NOT NULL,
  `rundatetime` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `email_server_setting`
--

CREATE TABLE `email_server_setting` (
  `email_seq` int(11) NOT NULL,
  `server_email_id` varchar(300) DEFAULT NULL,
  `server_email_password` varchar(200) DEFAULT NULL,
  `server_email_name` varchar(300) DEFAULT NULL,
  `server_email_host` varchar(200) DEFAULT NULL,
  `server_email_port` varchar(100) DEFAULT NULL,
  `server_email_action` varchar(100) DEFAULT NULL,
  `create_date` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `email_server_setting_log`
--

CREATE TABLE `email_server_setting_log` (
  `email_server_setting_log_seq` int(11) NOT NULL,
  `email_seq` int(11) DEFAULT NULL,
  `server_email_action` varchar(50) DEFAULT NULL,
  `date-time` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `event_cd` int(11) NOT NULL,
  `event_description` varchar(100) NOT NULL,
  `event_value` varchar(50) DEFAULT NULL,
  `register_address` varchar(50) DEFAULT NULL,
  `event_type` varchar(50) DEFAULT NULL,
  `active_flg` varchar(20) DEFAULT NULL,
  `old_new_add` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `event_log`
--

CREATE TABLE `event_log` (
  `event_log_seq` int(11) NOT NULL,
  `event_value` varchar(10) NOT NULL,
  `event_description` varchar(100) NOT NULL,
  `active_flg` varchar(1) NOT NULL,
  `register_address` varchar(50) DEFAULT NULL,
  `event_type` varchar(1) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  `action` varchar(10) DEFAULT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `chamber_seq` int(11) DEFAULT NULL,
  `reason_seq` int(11) DEFAULT NULL,
  `hmi` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `event_user`
--

CREATE TABLE `event_user` (
  `event_user_seq` int(11) NOT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `Sms` varchar(1) DEFAULT NULL,
  `email` varchar(1) DEFAULT NULL,
  `dashboard` varchar(1) DEFAULT NULL,
  `active_flg` varchar(1) DEFAULT NULL,
  `chamber_event_seq` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `event_user_log`
--

CREATE TABLE `event_user_log` (
  `event_user_log_seq` int(11) NOT NULL,
  `event_cd` varchar(10) DEFAULT NULL,
  `chamber_seq` decimal(10,0) DEFAULT NULL,
  `event_user_id` varchar(20) DEFAULT NULL,
  `Sms` varchar(1) DEFAULT NULL,
  `email` varchar(1) DEFAULT NULL,
  `dashboard` varchar(1) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  `action` varchar(10) DEFAULT NULL,
  `user_id` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `e_sign_notification`
--

CREATE TABLE `e_sign_notification` (
  `esign_notif_id` int(11) NOT NULL,
  `generatedby_id` int(11) DEFAULT NULL,
  `preparedby_id` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `checkedby_id` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `approvedby_id` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `report_id` int(11) DEFAULT NULL,
  `report_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `approved_stat` int(11) DEFAULT NULL,
  `reject_stat` int(11) DEFAULT NULL,
  `date_time` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `rejectst` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedback_seq` int(11) NOT NULL,
  `feedback_time` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fired_event_log`
--

CREATE TABLE `fired_event_log` (
  `fired_event_log_Seq` int(11) NOT NULL,
  `chamber_seq` decimal(10,0) DEFAULT NULL,
  `event_date_time` datetime DEFAULT NULL,
  `old_value` varchar(20) DEFAULT NULL,
  `new_value` varchar(20) DEFAULT NULL,
  `fired_event_type` varchar(1) DEFAULT NULL,
  `ack_date_time` datetime DEFAULT NULL,
  `ack_user_id` varchar(20) DEFAULT NULL,
  `reason_seq` varchar(100) DEFAULT NULL,
  `remarks` varchar(250) DEFAULT NULL,
  `event_status` varchar(1) DEFAULT NULL,
  `event_cd` varchar(10) DEFAULT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `reason_description` varchar(100) DEFAULT NULL,
  `hmi` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `historydb`
--

CREATE TABLE `historydb` (
  `historydb_seq` int(11) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `keystore`
--

CREATE TABLE `keystore` (
  `keystore_seq` int(11) NOT NULL,
  `mac_address` text,
  `keygene` text,
  `date-time` datetime DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `check` varchar(200) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `language_de`
--

CREATE TABLE `language_de` (
  `language_de` int(11) NOT NULL,
  `language` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `selected_date` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `select_stat` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lux_uv`
--

CREATE TABLE `lux_uv` (
  `lux_uv_seq` int(11) NOT NULL,
  `type` varchar(1) NOT NULL,
  `certificate_no` varchar(20) DEFAULT NULL,
  `certificate_date` datetime DEFAULT NULL,
  `duration_of_calibration` decimal(5,2) DEFAULT NULL,
  `required_light_intensity` decimal(5,2) DEFAULT NULL,
  `remarks` varchar(250) DEFAULT NULL,
  `chamber_seq` decimal(10,0) DEFAULT NULL,
  `lux_meter_serial_no` decimal(15,0) DEFAULT NULL,
  `Report_footer` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lux_uv_transaction`
--

CREATE TABLE `lux_uv_transaction` (
  `lux_uv_transaction_seq` int(11) NOT NULL,
  `readings` decimal(10,2) DEFAULT NULL,
  `required_time` varchar(15) DEFAULT NULL,
  `point` decimal(5,0) DEFAULT NULL,
  `lux_uv_seq` decimal(10,0) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `manage_footer`
--

CREATE TABLE `manage_footer` (
  `manage_footer_seq` int(11) NOT NULL,
  `status_name` varchar(100) DEFAULT NULL,
  `active` varchar(1) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `updated_user_id` int(11) DEFAULT NULL,
  `footer_order_by` int(11) DEFAULT NULL,
  `value` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `manual_backup_setting`
--

CREATE TABLE `manual_backup_setting` (
  `manual_db_cd` int(11) NOT NULL,
  `back_date` datetime DEFAULT NULL,
  `backup_location` varchar(100) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mktgraphicalweeklydates`
--

CREATE TABLE `mktgraphicalweeklydates` (
  `weekStart` datetime DEFAULT NULL,
  `WeekEnd` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `modbuslog`
--

CREATE TABLE `modbuslog` (
  `ID` int(11) NOT NULL,
  `ipadress` varchar(50) DEFAULT '0',
  `scannerFlag` varchar(1) DEFAULT '0',
  `MasterFlag` varchar(1) DEFAULT '0',
  `offline_scanner` varchar(1) DEFAULT '0',
  `offline_master` varchar(1) DEFAULT '0',
  `offline_Event` varchar(1) DEFAULT '0',
  `EventLog` varchar(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `open_door_details`
--

CREATE TABLE `open_door_details` (
  `open_door_seq` int(11) NOT NULL,
  `OpenDoor_DateTime` datetime DEFAULT NULL,
  `CloseDoor_DateTime` datetime DEFAULT NULL,
  `chamber_seq` decimal(10,0) DEFAULT NULL,
  `reason_seq` decimal(10,0) DEFAULT NULL,
  `remarks` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `photostability_details`
--

CREATE TABLE `photostability_details` (
  `Controller_Detail_Seq` mediumint(9) NOT NULL,
  `Record_Date_Time` datetime DEFAULT NULL,
  `UV_Current_LUX` decimal(18,2) DEFAULT NULL,
  `UV_SET_LUX` decimal(18,2) DEFAULT NULL,
  `UV_Total_LUX` decimal(18,2) DEFAULT NULL,
  `UV_remaining_Time` decimal(18,2) DEFAULT NULL,
  `Flourescent_Current_LUX` decimal(18,2) DEFAULT NULL,
  `Flourescent_SET_LUX` decimal(18,2) DEFAULT NULL,
  `Flourescent_Total_LUX` decimal(18,2) DEFAULT NULL,
  `Flourescent_remaining_Time` decimal(18,2) DEFAULT NULL,
  `chamber_seq` int(11) DEFAULT NULL,
  `lux_uv_type` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `printfrequency_settings`
--

CREATE TABLE `printfrequency_settings` (
  `print_freq_seq` int(11) NOT NULL,
  `chamber_seq` decimal(10,0) DEFAULT NULL,
  `printfrequency_master` decimal(5,0) DEFAULT NULL,
  `printfrequency_scanner` decimal(5,0) DEFAULT NULL,
  `frequency_date` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `printfrequency_settings_log`
--

CREATE TABLE `printfrequency_settings_log` (
  `Printfrequency_Settings_Log_Seq` int(11) NOT NULL,
  `chamber_seq` decimal(10,0) NOT NULL,
  `print_freq_seq` decimal(10,0) NOT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `Date_Time` datetime DEFAULT NULL,
  `action` varchar(10) DEFAULT NULL,
  `printfrequency_master` decimal(5,0) DEFAULT NULL,
  `printfrequency_scanner` decimal(5,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reason`
--

CREATE TABLE `reason` (
  `reason_seq` int(11) NOT NULL,
  `Reason_cd` varchar(3) DEFAULT NULL,
  `Reason_description` varchar(50) DEFAULT NULL,
  `active_flg` varchar(1) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(300) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  `ModbusValue` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reasonfromplc`
--

CREATE TABLE `reasonfromplc` (
  `PlcReasonId` int(11) NOT NULL,
  `reason_seq` int(11) DEFAULT NULL,
  `PlcReasonDate` varchar(100) DEFAULT NULL,
  `ip` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reason_log`
--

CREATE TABLE `reason_log` (
  `Reason_Log_Seq` int(11) NOT NULL,
  `reason_seq` decimal(10,0) NOT NULL,
  `Reason_cd` varchar(3) NOT NULL,
  `Reason_description` varchar(50) DEFAULT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `Date_Time` datetime DEFAULT NULL,
  `active_flag` varchar(10) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `action` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `report_log`
--

CREATE TABLE `report_log` (
  `report_log_seq` int(11) NOT NULL,
  `from_date_time` varchar(200) DEFAULT NULL,
  `to_date_time` varchar(200) DEFAULT NULL,
  `module` varchar(300) DEFAULT NULL,
  `sub_module` varchar(300) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `assign_to_approved_by` int(11) NOT NULL,
  `created_date_r` datetime DEFAULT NULL,
  `status` varchar(100) NOT NULL,
  `assign_to_prepared_by` varchar(200) DEFAULT NULL,
  `assign_date_prepared_by` datetime DEFAULT NULL,
  `assign_date_approved_by` datetime DEFAULT NULL,
  `approved_date_time` datetime DEFAULT NULL,
  `module_url` varchar(200) NOT NULL,
  `assign_to_checked_by` varchar(200) DEFAULT NULL,
  `assign_date_checked_by` varchar(200) DEFAULT NULL,
  `preparedby_view_report_time` varchar(100) DEFAULT NULL,
  `checkedby_view_report_time` varchar(200) DEFAULT NULL,
  `approvedby_view_report_time` varchar(100) DEFAULT NULL,
  `remark` varchar(300) DEFAULT NULL,
  `chamber_seq` int(11) DEFAULT NULL,
  `rejected_by` int(11) DEFAULT NULL,
  `rejected_remark` varchar(100) DEFAULT NULL,
  `c_remark` varchar(100) DEFAULT NULL,
  `a_remark` varchar(100) DEFAULT NULL,
  `approved_by_name` int(11) DEFAULT NULL,
  `cid_remark` int(11) DEFAULT NULL,
  `rejection_date` int(11) DEFAULT NULL,
  `check_by_name` int(11) DEFAULT NULL,
  `prepared_by_name` int(11) DEFAULT NULL,
  `checked_by` int(11) DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `aid_remark` int(11) DEFAULT NULL,
  `rejected_type` int(11) DEFAULT NULL,
  `pid_remark` int(11) DEFAULT NULL,
  `user_permission` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `report_type_master`
--

CREATE TABLE `report_type_master` (
  `report_master_seq` int(11) NOT NULL,
  `report_master_name` varchar(300) NOT NULL,
  `active_flag` varchar(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `report_type_scanner`
--

CREATE TABLE `report_type_scanner` (
  `report_scanner_seq` int(11) NOT NULL,
  `no_of_temp_channel` int(11) DEFAULT NULL,
  `no_of_hum_channel` int(11) DEFAULT NULL,
  `report_scanner_name` varchar(300) DEFAULT NULL,
  `active_flag` varchar(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `scanner_details`
--

CREATE TABLE `scanner_details` (
  `Scanner_Detail_Seq` int(11) NOT NULL,
  `chamber_seq` decimal(10,0) NOT NULL,
  `Record_Date_Time` varchar(200) DEFAULT NULL,
  `Temperature_Value` decimal(5,1) DEFAULT NULL,
  `Humidity_Value` decimal(5,1) DEFAULT NULL,
  `component_cd` varchar(10) DEFAULT NULL,
  `Temperature_setpoint` decimal(5,1) NOT NULL DEFAULT '0.0',
  `Humidity_setpoint` decimal(5,2) NOT NULL DEFAULT '0.00',
  `print_frequency` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `scanner_detail_data`
--

CREATE TABLE `scanner_detail_data` (
  `Scanner_Detail_Data_Seq` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `setpoint_settings`
--

CREATE TABLE `setpoint_settings` (
  `set_sv_seq` int(11) NOT NULL,
  `Temperature_SetPoint` decimal(10,1) DEFAULT NULL,
  `Humidity_SetPoint` decimal(10,1) DEFAULT NULL,
  `chamber_seq` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `setpoint_settings_log`
--

CREATE TABLE `setpoint_settings_log` (
  `Setpoint_Settings_Log_Seq` int(11) NOT NULL,
  `chamber_seq` decimal(10,0) NOT NULL,
  `Temperature_SetPoint` decimal(10,1) DEFAULT NULL,
  `Humidity_SetPoint` decimal(10,1) DEFAULT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `set_sv_seq` decimal(10,0) NOT NULL,
  `Date_Time` datetime DEFAULT NULL,
  `action` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `set_date_time`
--

CREATE TABLE `set_date_time` (
  `set_date_time_seq` int(11) NOT NULL,
  `set_date_time` datetime DEFAULT NULL,
  `chamber_seq` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `set_date_time_log`
--

CREATE TABLE `set_date_time_log` (
  `Set_Date_Time_Log_Seq` int(11) NOT NULL,
  `chamber_seq` decimal(10,0) NOT NULL,
  `Date_Time` datetime DEFAULT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `set_date_time_seq` decimal(10,0) NOT NULL,
  `Set_Date_Time` datetime DEFAULT NULL,
  `action` varchar(10) DEFAULT NULL,
  `old_date_time` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sms_email_log`
--

CREATE TABLE `sms_email_log` (
  `sms_eml_id` int(11) NOT NULL,
  `chamber_seq` int(11) DEFAULT NULL,
  `user_id` varchar(300) DEFAULT NULL,
  `email_id` varchar(300) DEFAULT NULL,
  `mobile_no` varchar(300) DEFAULT NULL,
  `msg` text,
  `temp_set` varchar(100) DEFAULT NULL,
  `temp_prv` varchar(100) DEFAULT NULL,
  `hum_set` varchar(100) DEFAULT NULL,
  `hum_prv` varchar(100) DEFAULT NULL,
  `event_dc` text,
  `event_date` varchar(200) DEFAULT NULL,
  `date_time` timestamp NULL DEFAULT NULL,
  `SMSstatus` text,
  `EmailStatus` text,
  `ActiveUser` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sms_server_setting`
--

CREATE TABLE `sms_server_setting` (
  `sms_user_id` int(11) NOT NULL,
  `sender_id` varchar(50) DEFAULT NULL,
  `active_flg` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sw_version`
--

CREATE TABLE `sw_version` (
  `sw_ver` int(11) NOT NULL,
  `sw_descp` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `date_time` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_company`
--

CREATE TABLE `tbl_company` (
  `company_id` int(11) NOT NULL,
  `company_name` varchar(200) NOT NULL,
  `company_address` text NOT NULL,
  `company_logo` varchar(200) NOT NULL,
  `company_contact` varchar(20) NOT NULL,
  `company_code` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `pincode` int(11) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `contact_person_name` varchar(200) DEFAULT NULL,
  `contact_person_number` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_company_log`
--

CREATE TABLE `tbl_company_log` (
  `tbl_company_log_seq` int(11) NOT NULL,
  `company_id` int(11) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_group_log`
--

CREATE TABLE `tbl_group_log` (
  `group_log_id` int(11) NOT NULL,
  `group_name` varchar(200) NOT NULL,
  `modules` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `action` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_key_shortcut`
--

CREATE TABLE `tbl_key_shortcut` (
  `key_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `key_value` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `active_flg` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_key_shortcut_log`
--

CREATE TABLE `tbl_key_shortcut_log` (
  `key_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `key_value` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `action` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_language_master`
--

CREATE TABLE `tbl_language_master` (
  `lang_id` int(11) NOT NULL,
  `lang_field` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `lang_en` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `lang_ch` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_module`
--

CREATE TABLE `tbl_module` (
  `module_id` int(11) NOT NULL,
  `module_name` varchar(100) DEFAULT NULL,
  `lang_id` varchar(100) DEFAULT NULL,
  `module_path` varchar(100) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `chaild_id` int(11) DEFAULT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `show_left` int(11) DEFAULT NULL,
  `hide` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_notification_count`
--

CREATE TABLE `tbl_notification_count` (
  `notification_id` int(11) NOT NULL,
  `active_flag` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_opt`
--

CREATE TABLE `tbl_opt` (
  `otp_id` int(11) NOT NULL,
  `mobile_number` varchar(20) NOT NULL,
  `otp` varchar(6) NOT NULL,
  `username` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_password_history`
--

CREATE TABLE `tbl_password_history` (
  `pass_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_report_logs`
--

CREATE TABLE `tbl_report_logs` (
  `report_log_id` int(11) NOT NULL,
  `report_log_seq` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_restoredb`
--

CREATE TABLE `tbl_restoredb` (
  `tbl_restore_seq` int(11) NOT NULL,
  `date_time` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `restore_status` varchar(3) DEFAULT NULL,
  `database_name` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_restoreflag`
--

CREATE TABLE `tbl_restoreflag` (
  `restore_id` int(11) NOT NULL,
  `flag` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_date_flag` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `event_cd` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session_time`
--

CREATE TABLE `tbl_session_time` (
  `session_id` int(11) NOT NULL,
  `session_time` int(11) NOT NULL,
  `expiry_days` int(11) NOT NULL,
  `set_password_attempt` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session_time_log`
--

CREATE TABLE `tbl_session_time_log` (
  `session_id` int(11) NOT NULL,
  `session_time` int(11) NOT NULL,
  `expiry_days` int(11) NOT NULL,
  `action` varchar(200) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `user_image` varchar(200) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `newpassword` varchar(200) DEFAULT NULL,
  `email_address` text NOT NULL,
  `mobile_number` varchar(20) NOT NULL,
  `address` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `user_status` enum('0','1') NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` datetime DEFAULT NULL,
  `user_type` varchar(100) NOT NULL DEFAULT 'USER',
  `user_sign` varchar(250) NOT NULL,
  `user_permission` varchar(50) NOT NULL,
  `expiry_date` date NOT NULL,
  `hmi` varchar(100) DEFAULT NULL,
  `biometric_uid` varchar(100) DEFAULT NULL,
  `group_id` int(11) NOT NULL,
  `change_status` tinyint(1) NOT NULL DEFAULT '1',
  `login_attempt` tinyint(1) NOT NULL,
  `active_flg` int(11) DEFAULT NULL,
  `logged_id` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_access`
--

CREATE TABLE `tbl_user_access` (
  `access_id` int(11) NOT NULL,
  `modules` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_name` varchar(100) NOT NULL,
  `user_status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `template`
--

CREATE TABLE `template` (
  `template_seq` int(11) NOT NULL,
  `template_desc` varchar(200) DEFAULT NULL,
  `template_name` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `timezone`
--

CREATE TABLE `timezone` (
  `timezone_seq` int(11) NOT NULL,
  `timezone` text,
  `created_date_t` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_history`
--

CREATE TABLE `user_history` (
  `user_history_seq` int(11) NOT NULL,
  `date_time` datetime DEFAULT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `resource_name` varchar(100) DEFAULT NULL,
  `action` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_restoredb_log`
--

CREATE TABLE `user_restoredb_log` (
  `log_id` int(11) NOT NULL,
  `user_id` varchar(200) DEFAULT NULL,
  `log_time` varchar(2000) DEFAULT NULL,
  `action` varchar(2000) DEFAULT NULL,
  `log_message` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_sessions`
--

CREATE TABLE `user_sessions` (
  `user_id` int(11) NOT NULL,
  `session_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `last_activity` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `utilities_details`
--

CREATE TABLE `utilities_details` (
  `utilities_details_seq` int(11) NOT NULL,
  `fired_event_log_Seq` int(11) DEFAULT NULL,
  `chamber_seq` int(11) DEFAULT NULL,
  `event_cd` int(11) DEFAULT NULL,
  `reason_seq` int(11) DEFAULT NULL,
  `remark` varchar(200) DEFAULT NULL,
  `Record_Date_Time` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `action`
--
ALTER TABLE `action`
  ADD PRIMARY KEY (`action_seq`);

--
-- Indexes for table `all_modbus_run`
--
ALTER TABLE `all_modbus_run`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_parm`
--
ALTER TABLE `app_parm`
  ADD PRIMARY KEY (`parm_seq`);

--
-- Indexes for table `backup_setting`
--
ALTER TABLE `backup_setting`
  ADD PRIMARY KEY (`backup_cd`);

--
-- Indexes for table `backup_setting_log`
--
ALTER TABLE `backup_setting_log`
  ADD PRIMARY KEY (`backup_cd`);

--
-- Indexes for table `chamber_component`
--
ALTER TABLE `chamber_component`
  ADD PRIMARY KEY (`chamber_component_seq`),
  ADD KEY `chamber_seq` (`chamber_seq`);

--
-- Indexes for table `chamber_event`
--
ALTER TABLE `chamber_event`
  ADD PRIMARY KEY (`chamber_event_seq`);

--
-- Indexes for table `chamber_master`
--
ALTER TABLE `chamber_master`
  ADD PRIMARY KEY (`chamber_seq`);

--
-- Indexes for table `chamber_master_log`
--
ALTER TABLE `chamber_master_log`
  ADD PRIMARY KEY (`Chamber_Master_Log_Seq`);

--
-- Indexes for table `channel`
--
ALTER TABLE `channel`
  ADD PRIMARY KEY (`Channel_Seq`);

--
-- Indexes for table `channel_settings`
--
ALTER TABLE `channel_settings`
  ADD PRIMARY KEY (`channel_setting_seq`),
  ADD KEY `chamber_seq` (`chamber_seq`);

--
-- Indexes for table `channel_settings_log`
--
ALTER TABLE `channel_settings_log`
  ADD PRIMARY KEY (`Channel_Settings_Log_Seq`);

--
-- Indexes for table `close_door_setting_log`
--
ALTER TABLE `close_door_setting_log`
  ADD PRIMARY KEY (`Close_Door_Setting_Log_Seq`);

--
-- Indexes for table `compinstall_name`
--
ALTER TABLE `compinstall_name`
  ADD PRIMARY KEY (`compinstall_name_seq`);

--
-- Indexes for table `component`
--
ALTER TABLE `component`
  ADD PRIMARY KEY (`component-seq`);

--
-- Indexes for table `controller_details`
--
ALTER TABLE `controller_details`
  ADD PRIMARY KEY (`Controller_Detail_Seq`),
  ADD UNIQUE KEY `print_frequency` (`Controller_Detail_Seq`),
  ADD KEY `chamber_seq` (`chamber_seq`),
  ADD KEY `idx_chk` (`chamber_seq`,`Record_Date_Time`);

--
-- Indexes for table `coutner_record`
--
ALTER TABLE `coutner_record`
  ADD PRIMARY KEY (`counterid`);

--
-- Indexes for table `cronjob_response`
--
ALTER TABLE `cronjob_response`
  ADD PRIMARY KEY (`cron_sr`);

--
-- Indexes for table `datetimetb`
--
ALTER TABLE `datetimetb`
  ADD PRIMARY KEY (`datetimeseq`);

--
-- Indexes for table `email_server_setting`
--
ALTER TABLE `email_server_setting`
  ADD PRIMARY KEY (`email_seq`);

--
-- Indexes for table `email_server_setting_log`
--
ALTER TABLE `email_server_setting_log`
  ADD PRIMARY KEY (`email_server_setting_log_seq`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`event_cd`);

--
-- Indexes for table `event_log`
--
ALTER TABLE `event_log`
  ADD PRIMARY KEY (`event_log_seq`);

--
-- Indexes for table `event_user`
--
ALTER TABLE `event_user`
  ADD PRIMARY KEY (`event_user_seq`);

--
-- Indexes for table `event_user_log`
--
ALTER TABLE `event_user_log`
  ADD PRIMARY KEY (`event_user_log_seq`);

--
-- Indexes for table `e_sign_notification`
--
ALTER TABLE `e_sign_notification`
  ADD PRIMARY KEY (`esign_notif_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_seq`);

--
-- Indexes for table `fired_event_log`
--
ALTER TABLE `fired_event_log`
  ADD PRIMARY KEY (`fired_event_log_Seq`);

--
-- Indexes for table `historydb`
--
ALTER TABLE `historydb`
  ADD PRIMARY KEY (`historydb_seq`);

--
-- Indexes for table `keystore`
--
ALTER TABLE `keystore`
  ADD PRIMARY KEY (`keystore_seq`);

--
-- Indexes for table `language_de`
--
ALTER TABLE `language_de`
  ADD PRIMARY KEY (`language_de`);

--
-- Indexes for table `lux_uv`
--
ALTER TABLE `lux_uv`
  ADD PRIMARY KEY (`lux_uv_seq`),
  ADD UNIQUE KEY `lux_uv_ibfk_2` (`chamber_seq`) USING BTREE;

--
-- Indexes for table `lux_uv_transaction`
--
ALTER TABLE `lux_uv_transaction`
  ADD PRIMARY KEY (`lux_uv_transaction_seq`),
  ADD UNIQUE KEY `lux_uv_seq` (`lux_uv_seq`);

--
-- Indexes for table `manage_footer`
--
ALTER TABLE `manage_footer`
  ADD PRIMARY KEY (`manage_footer_seq`);

--
-- Indexes for table `manual_backup_setting`
--
ALTER TABLE `manual_backup_setting`
  ADD PRIMARY KEY (`manual_db_cd`);

--
-- Indexes for table `modbuslog`
--
ALTER TABLE `modbuslog`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `open_door_details`
--
ALTER TABLE `open_door_details`
  ADD PRIMARY KEY (`open_door_seq`);

--
-- Indexes for table `photostability_details`
--
ALTER TABLE `photostability_details`
  ADD PRIMARY KEY (`Controller_Detail_Seq`);

--
-- Indexes for table `printfrequency_settings`
--
ALTER TABLE `printfrequency_settings`
  ADD PRIMARY KEY (`print_freq_seq`),
  ADD KEY `chamber_seq` (`chamber_seq`);

--
-- Indexes for table `printfrequency_settings_log`
--
ALTER TABLE `printfrequency_settings_log`
  ADD PRIMARY KEY (`Printfrequency_Settings_Log_Seq`);

--
-- Indexes for table `reason`
--
ALTER TABLE `reason`
  ADD PRIMARY KEY (`reason_seq`);

--
-- Indexes for table `reasonfromplc`
--
ALTER TABLE `reasonfromplc`
  ADD PRIMARY KEY (`PlcReasonId`);

--
-- Indexes for table `reason_log`
--
ALTER TABLE `reason_log`
  ADD PRIMARY KEY (`Reason_Log_Seq`);

--
-- Indexes for table `report_log`
--
ALTER TABLE `report_log`
  ADD PRIMARY KEY (`report_log_seq`);

--
-- Indexes for table `report_type_master`
--
ALTER TABLE `report_type_master`
  ADD PRIMARY KEY (`report_master_seq`);

--
-- Indexes for table `report_type_scanner`
--
ALTER TABLE `report_type_scanner`
  ADD PRIMARY KEY (`report_scanner_seq`);

--
-- Indexes for table `scanner_details`
--
ALTER TABLE `scanner_details`
  ADD PRIMARY KEY (`Scanner_Detail_Seq`),
  ADD KEY `component_cd` (`component_cd`),
  ADD KEY `chamber_seq` (`chamber_seq`),
  ADD KEY `Record_Date_Time` (`Record_Date_Time`),
  ADD KEY `idx_chk` (`chamber_seq`,`Record_Date_Time`,`component_cd`);

--
-- Indexes for table `scanner_detail_data`
--
ALTER TABLE `scanner_detail_data`
  ADD PRIMARY KEY (`Scanner_Detail_Data_Seq`);

--
-- Indexes for table `setpoint_settings`
--
ALTER TABLE `setpoint_settings`
  ADD PRIMARY KEY (`set_sv_seq`),
  ADD KEY `chamber_seq` (`chamber_seq`);

--
-- Indexes for table `setpoint_settings_log`
--
ALTER TABLE `setpoint_settings_log`
  ADD PRIMARY KEY (`Setpoint_Settings_Log_Seq`);

--
-- Indexes for table `set_date_time`
--
ALTER TABLE `set_date_time`
  ADD PRIMARY KEY (`set_date_time_seq`),
  ADD KEY `chamber_seq` (`chamber_seq`);

--
-- Indexes for table `set_date_time_log`
--
ALTER TABLE `set_date_time_log`
  ADD PRIMARY KEY (`Set_Date_Time_Log_Seq`);

--
-- Indexes for table `sms_email_log`
--
ALTER TABLE `sms_email_log`
  ADD PRIMARY KEY (`sms_eml_id`);

--
-- Indexes for table `sms_server_setting`
--
ALTER TABLE `sms_server_setting`
  ADD PRIMARY KEY (`sms_user_id`);

--
-- Indexes for table `sw_version`
--
ALTER TABLE `sw_version`
  ADD PRIMARY KEY (`sw_ver`);

--
-- Indexes for table `tbl_company`
--
ALTER TABLE `tbl_company`
  ADD PRIMARY KEY (`company_id`);

--
-- Indexes for table `tbl_company_log`
--
ALTER TABLE `tbl_company_log`
  ADD PRIMARY KEY (`tbl_company_log_seq`);

--
-- Indexes for table `tbl_group_log`
--
ALTER TABLE `tbl_group_log`
  ADD PRIMARY KEY (`group_log_id`);

--
-- Indexes for table `tbl_key_shortcut`
--
ALTER TABLE `tbl_key_shortcut`
  ADD PRIMARY KEY (`key_id`);

--
-- Indexes for table `tbl_key_shortcut_log`
--
ALTER TABLE `tbl_key_shortcut_log`
  ADD PRIMARY KEY (`key_id`);

--
-- Indexes for table `tbl_language_master`
--
ALTER TABLE `tbl_language_master`
  ADD PRIMARY KEY (`lang_id`);

--
-- Indexes for table `tbl_module`
--
ALTER TABLE `tbl_module`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `tbl_notification_count`
--
ALTER TABLE `tbl_notification_count`
  ADD PRIMARY KEY (`notification_id`);

--
-- Indexes for table `tbl_opt`
--
ALTER TABLE `tbl_opt`
  ADD PRIMARY KEY (`otp_id`);

--
-- Indexes for table `tbl_password_history`
--
ALTER TABLE `tbl_password_history`
  ADD PRIMARY KEY (`pass_id`);

--
-- Indexes for table `tbl_report_logs`
--
ALTER TABLE `tbl_report_logs`
  ADD PRIMARY KEY (`report_log_id`);

--
-- Indexes for table `tbl_restoredb`
--
ALTER TABLE `tbl_restoredb`
  ADD PRIMARY KEY (`tbl_restore_seq`);

--
-- Indexes for table `tbl_restoreflag`
--
ALTER TABLE `tbl_restoreflag`
  ADD PRIMARY KEY (`restore_id`);

--
-- Indexes for table `tbl_session_time`
--
ALTER TABLE `tbl_session_time`
  ADD PRIMARY KEY (`session_id`);

--
-- Indexes for table `tbl_session_time_log`
--
ALTER TABLE `tbl_session_time_log`
  ADD PRIMARY KEY (`session_id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `tbl_user_access`
--
ALTER TABLE `tbl_user_access`
  ADD PRIMARY KEY (`access_id`);

--
-- Indexes for table `template`
--
ALTER TABLE `template`
  ADD PRIMARY KEY (`template_seq`);

--
-- Indexes for table `timezone`
--
ALTER TABLE `timezone`
  ADD PRIMARY KEY (`timezone_seq`);

--
-- Indexes for table `user_history`
--
ALTER TABLE `user_history`
  ADD PRIMARY KEY (`user_history_seq`);

--
-- Indexes for table `user_restoredb_log`
--
ALTER TABLE `user_restoredb_log`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `utilities_details`
--
ALTER TABLE `utilities_details`
  ADD PRIMARY KEY (`utilities_details_seq`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `action`
--
ALTER TABLE `action`
  MODIFY `action_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `all_modbus_run`
--
ALTER TABLE `all_modbus_run`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `app_parm`
--
ALTER TABLE `app_parm`
  MODIFY `parm_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `backup_setting`
--
ALTER TABLE `backup_setting`
  MODIFY `backup_cd` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `backup_setting_log`
--
ALTER TABLE `backup_setting_log`
  MODIFY `backup_cd` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chamber_component`
--
ALTER TABLE `chamber_component`
  MODIFY `chamber_component_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chamber_event`
--
ALTER TABLE `chamber_event`
  MODIFY `chamber_event_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chamber_master_log`
--
ALTER TABLE `chamber_master_log`
  MODIFY `Chamber_Master_Log_Seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `channel_settings`
--
ALTER TABLE `channel_settings`
  MODIFY `channel_setting_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `channel_settings_log`
--
ALTER TABLE `channel_settings_log`
  MODIFY `Channel_Settings_Log_Seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `close_door_setting_log`
--
ALTER TABLE `close_door_setting_log`
  MODIFY `Close_Door_Setting_Log_Seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `compinstall_name`
--
ALTER TABLE `compinstall_name`
  MODIFY `compinstall_name_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `component`
--
ALTER TABLE `component`
  MODIFY `component-seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `controller_details`
--
ALTER TABLE `controller_details`
  MODIFY `Controller_Detail_Seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `coutner_record`
--
ALTER TABLE `coutner_record`
  MODIFY `counterid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `datetimetb`
--
ALTER TABLE `datetimetb`
  MODIFY `datetimeseq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `email_server_setting`
--
ALTER TABLE `email_server_setting`
  MODIFY `email_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `email_server_setting_log`
--
ALTER TABLE `email_server_setting_log`
  MODIFY `email_server_setting_log_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `event_cd` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `event_log`
--
ALTER TABLE `event_log`
  MODIFY `event_log_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `event_user`
--
ALTER TABLE `event_user`
  MODIFY `event_user_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `event_user_log`
--
ALTER TABLE `event_user_log`
  MODIFY `event_user_log_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `e_sign_notification`
--
ALTER TABLE `e_sign_notification`
  MODIFY `esign_notif_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedback_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fired_event_log`
--
ALTER TABLE `fired_event_log`
  MODIFY `fired_event_log_Seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `historydb`
--
ALTER TABLE `historydb`
  MODIFY `historydb_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `keystore`
--
ALTER TABLE `keystore`
  MODIFY `keystore_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `language_de`
--
ALTER TABLE `language_de`
  MODIFY `language_de` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `manage_footer`
--
ALTER TABLE `manage_footer`
  MODIFY `manage_footer_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `manual_backup_setting`
--
ALTER TABLE `manual_backup_setting`
  MODIFY `manual_db_cd` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modbuslog`
--
ALTER TABLE `modbuslog`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `open_door_details`
--
ALTER TABLE `open_door_details`
  MODIFY `open_door_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `photostability_details`
--
ALTER TABLE `photostability_details`
  MODIFY `Controller_Detail_Seq` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `printfrequency_settings`
--
ALTER TABLE `printfrequency_settings`
  MODIFY `print_freq_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `printfrequency_settings_log`
--
ALTER TABLE `printfrequency_settings_log`
  MODIFY `Printfrequency_Settings_Log_Seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reason`
--
ALTER TABLE `reason`
  MODIFY `reason_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reasonfromplc`
--
ALTER TABLE `reasonfromplc`
  MODIFY `PlcReasonId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reason_log`
--
ALTER TABLE `reason_log`
  MODIFY `Reason_Log_Seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_log`
--
ALTER TABLE `report_log`
  MODIFY `report_log_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_type_master`
--
ALTER TABLE `report_type_master`
  MODIFY `report_master_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_type_scanner`
--
ALTER TABLE `report_type_scanner`
  MODIFY `report_scanner_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `scanner_details`
--
ALTER TABLE `scanner_details`
  MODIFY `Scanner_Detail_Seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `setpoint_settings`
--
ALTER TABLE `setpoint_settings`
  MODIFY `set_sv_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `setpoint_settings_log`
--
ALTER TABLE `setpoint_settings_log`
  MODIFY `Setpoint_Settings_Log_Seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `set_date_time`
--
ALTER TABLE `set_date_time`
  MODIFY `set_date_time_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `set_date_time_log`
--
ALTER TABLE `set_date_time_log`
  MODIFY `Set_Date_Time_Log_Seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sms_email_log`
--
ALTER TABLE `sms_email_log`
  MODIFY `sms_eml_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sms_server_setting`
--
ALTER TABLE `sms_server_setting`
  MODIFY `sms_user_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sw_version`
--
ALTER TABLE `sw_version`
  MODIFY `sw_ver` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_company`
--
ALTER TABLE `tbl_company`
  MODIFY `company_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_company_log`
--
ALTER TABLE `tbl_company_log`
  MODIFY `tbl_company_log_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_group_log`
--
ALTER TABLE `tbl_group_log`
  MODIFY `group_log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_key_shortcut`
--
ALTER TABLE `tbl_key_shortcut`
  MODIFY `key_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_key_shortcut_log`
--
ALTER TABLE `tbl_key_shortcut_log`
  MODIFY `key_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_language_master`
--
ALTER TABLE `tbl_language_master`
  MODIFY `lang_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_module`
--
ALTER TABLE `tbl_module`
  MODIFY `module_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_notification_count`
--
ALTER TABLE `tbl_notification_count`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_opt`
--
ALTER TABLE `tbl_opt`
  MODIFY `otp_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_password_history`
--
ALTER TABLE `tbl_password_history`
  MODIFY `pass_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_report_logs`
--
ALTER TABLE `tbl_report_logs`
  MODIFY `report_log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_restoredb`
--
ALTER TABLE `tbl_restoredb`
  MODIFY `tbl_restore_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_restoreflag`
--
ALTER TABLE `tbl_restoreflag`
  MODIFY `restore_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_session_time`
--
ALTER TABLE `tbl_session_time`
  MODIFY `session_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_session_time_log`
--
ALTER TABLE `tbl_session_time_log`
  MODIFY `session_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_user_access`
--
ALTER TABLE `tbl_user_access`
  MODIFY `access_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `template`
--
ALTER TABLE `template`
  MODIFY `template_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `timezone`
--
ALTER TABLE `timezone`
  MODIFY `timezone_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_history`
--
ALTER TABLE `user_history`
  MODIFY `user_history_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_restoredb_log`
--
ALTER TABLE `user_restoredb_log`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `utilities_details`
--
ALTER TABLE `utilities_details`
  MODIFY `utilities_details_seq` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `setpoint_settings`
--
ALTER TABLE `setpoint_settings`
  ADD CONSTRAINT `setpoint_settings_ibfk_1` FOREIGN KEY (`chamber_seq`) REFERENCES `chamber_master` (`chamber_seq`),
  ADD CONSTRAINT `setpoint_settings_ibfk_2` FOREIGN KEY (`chamber_seq`) REFERENCES `chamber_master` (`chamber_seq`);

--
-- Constraints for table `set_date_time`
--
ALTER TABLE `set_date_time`
  ADD CONSTRAINT `set_date_time_ibfk_1` FOREIGN KEY (`chamber_seq`) REFERENCES `chamber_master` (`chamber_seq`),
  ADD CONSTRAINT `set_date_time_ibfk_2` FOREIGN KEY (`chamber_seq`) REFERENCES `chamber_master` (`chamber_seq`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
