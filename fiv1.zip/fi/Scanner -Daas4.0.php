<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Scanner extends MY_Controller {
     public function __construct()
    {
        parent::__construct();
        $this->load->helper('pdf');
        $this->load->model('temprature_model','temprature');
    }
	public function index()
	{
	    $url="";
	    if(isset($_POST['btn-submit']))
		{
		    
			$from_date=date('d-m-Y H:i:00',strtotime($_POST['from_date']));
			$to_date=date('d-m-Y H:i:00',strtotime($_POST['to_date']));
			$chamber_id = explode(",", $_POST['chamber_id']);
		    $chamber=$chamber_id[0];
		    $chamber_type=$chamber_id[1];

			$curdate=strtotime($_POST['from_date']);
            $mydate=strtotime($_POST['to_date']);
			$datediff = ($mydate/(60*60*24) - $curdate/(60*60*24));
            $days=abs($datediff);
	 		if ($curdate > $mydate ) {
	                $this->session->set_flashdata('error','Please select From Date smaller than To Date');
				    redirect(base_url('analysis/scanner'));
				}
			elseif($days>183)
			{
				$this->session->set_flashdata('error','Please select from date and to date between six months period only');
			    redirect(base_url('analysis/scanner'));

			}
			else
			{
			    if($this->session->userdata('user_permission')=='PREPARED')
			    {
			        $getfooter = $this->common_model->get_records('manage_footer',array('active'),array('value'=>'CHECK'),TRUE);
                    $getactive_flg = $getfooter['active'];
        			$url=base_url('analysis/scanner/generat_pdf/'.$from_date.'/'.$to_date.'/'.$chamber.'/?prepar_by='.$this->session->userdata('user_id').'&vr=&report_seq=&remark_id=&rt=gr');
        			if($getactive_flg == 'Y')
        			{
        			$insert_array = array(
								'from_date_time	'=>$this->input->post('from_date'),
								'to_date_time'=>$this->input->post('to_date'),
								'module'=>'Analysis',
								'sub_module'=>'Scanner Tabular',
								'user_id'=>$this->session->userdata('user_id'),
								'assign_to_prepared_by'=>$this->session->userdata('user_id'),
								'assign_date_prepared_by'=>date('Y-m-d H:i:s'),
								'module_url'=>$url,
								'created_date_r' => date('Y-m-d H:i:s'),
								);
			$this->common_model->add_records('report_log',$insert_array);
        			}
        			else
        			{
        			    	$insert_array = array(
								'from_date_time	'=>$this->input->post('from_date'),
								'to_date_time'=>$this->input->post('to_date'),
								'module'=>'Analysis',
								'sub_module'=>'Scanner Tabular',
								'user_id'=>$this->session->userdata('user_id'),
								'assign_to_prepared_by'=>$this->session->userdata('user_id'),
								'assign_date_prepared_by'=>date('Y-m-d H:i:s'),
									'assign_to_checked_by'=>'NA',
    								'assign_date_checked_by'=>'NA',
    								'checkedby_view_report_time'=>'NA',
								'module_url'=>$url,
								'created_date_r' => date('Y-m-d H:i:s'),
								);
			$this->common_model->add_records('report_log',$insert_array);
        			}
			}elseif($this->session->userdata('user_permission')=='CHECK'){
			    $url=base_url('analysis/scanner/generat_pdf/'.$from_date.'/'.$to_date.'/'.$chamber.'/?check_by='.$this->session->userdata('user_id').'&vr=&report_seq=&remark_id=&rt=gr');
			$insert_array = array(
								'from_date_time	'=>$this->input->post('from_date'),
								'to_date_time'=>$this->input->post('to_date'),
								'module'=>'Analysis',
								'sub_module'=>'Scanner Tabular',
								'user_id'=>$this->session->userdata('user_id'),
								'assign_to_checked_by'=>$this->session->userdata('user_id'),
								'assign_date_checked_by'=>date('Y-m-d H:i:s'),
								'module_url'=>$url,
								'created_date_r' => date('Y-m-d H:i:s'),
								);
			$this->common_model->add_records('report_log',$insert_array);
			    
			}elseif($this->session->userdata('user_permission')=='APPROVED'){
			    $url=base_url('analysis/scanner/generat_pdf/'.$from_date.'/'.$to_date.'/'.$chamber.'/?approve_by='.$this->session->userdata('user_id').'&vr=&report_seq=&remark_id=&rt=gr');
			
			$insert_array = array(
								'from_date_time	'=>$this->input->post('from_date'),
								'to_date_time'=>$this->input->post('to_date'),
								'module'=>'Analysis',
								'sub_module'=>'Scanner Tabular',
								'user_id'=>$this->session->userdata('user_id'),
								'assign_to_approved_by'=>$this->session->userdata('user_id'),
								'assign_date_approved_by'=>date('Y-m-d H:i:s'),
								'module_url'=>$url,
								'created_date_r' => date('Y-m-d H:i:s'),
										 'assign_to_prepared_by' => 'NA',
				                    'assign_to_checked_by' =>'NA',
				                    'assign_date_checked_by' =>'NA',
				                    'checkedby_view_report_time'=>'NA',
								);
			$this->common_model->add_records('report_log',$insert_array);
			    
			    
			}else{
			         if($this->session->userdata('user_type')=='ADMIN'){
			              $url=base_url('analysis/scanner/generat_pdf/'.$from_date.'/'.$to_date.'/'.$report.'/?approve_by='.$this->session->userdata('user_id').'&vr=&report_seq=&remark_id=&rt=gr');
			$insert_array = array(
								'from_date_time	'=>$this->input->post('from_date'),
								'to_date_time'=>$this->input->post('to_date'),
								'module'=>'Analysis',
								'sub_module'=>'Scanner Tabular',
								'user_id'=>$this->session->userdata('user_id'),
								'assign_to_approved_by'=>$this->session->userdata('user_id'),
								'assign_date_approved_by'=>date('Y-m-d H:i:s'),
								'module_url'=>$url,
								'created_date_r' => date('Y-m-d H:i:s'),
										 'assign_to_prepared_by' => 'NA',
				                    'assign_to_checked_by' =>'NA',
				                    'assign_date_checked_by' =>'NA',
				                    'checkedby_view_report_time'=>'NA',
								);
			$this->common_model->add_records('report_log',$insert_array);
			             
			         }else{
			             
			             	$urls=base_url('audit/scanner/generat_pdf/'.$chamber.'/'.$from_date.'/'.$to_date);
			         }
			    
			}
			    
			}
			
		}
		$this->db->where("active_flg","1");
		$chamber_details=$this->common_model->get_records('chamber_master','');
		
		$data=array('middle_content'=>'scanner-tabular-view','chamber_details'=>$chamber_details,'url'=>$url);	
		$this->load->view('template',$data);
	}
	public function generat_pdf($from_date,$to_date,$chamber)
	{
	    $from_dates=str_replace('%20','', $from_date);
		 $to_dates=str_replace('%20','', $to_date);
		 if($_GET['report_seq'] !="" && $_GET['vr'] == "check")
		 {
		  $report_seq = $_GET['report_seq'];
		 $update_array = array(
		                    'checkedby_view_report_time'=>date('Y-m-d H:i:s'),
		                    );
		  $where_array=array('report_log_seq'=>$report_seq);
		 
		  $this->common_model->update_records('report_log',$update_array,$where_array);
		 
		 }
		 if($_GET['report_seq'] !="" && $_GET['vr'] == "prepare")
		 {
		  $report_seq = $_GET['report_seq'];
		 $update_array = array(
		                    'preparedby_view_report_time'=>date('Y-m-d H:i:s'),
		                    );
		  $where_array=array('report_log_seq'=>$report_seq);
		 
		  $this->common_model->update_records('report_log',$update_array,$where_array);
		
		 }
		 if($_GET['report_seq'] !="" && $_GET['vr'] == "approve")
		 {
		  $report_seq = $_GET['report_seq'];
		 $update_array = array(
		                    'approvedby_view_report_time'=>date('Y-m-d H:i:s'),
		                    );
		  $where_array=array('report_log_seq'=>$report_seq);
		 
		  $this->common_model->update_records('report_log',$update_array,$where_array);
		
		 }
		$this->make($from_dates,$to_dates,$chamber);
	}
public function make($from_date,$to_date,$chamber)
	{

$report_seq = $_GET['report_seq'];
        	$userid = $this->session->userdata('user_id');
        $get_username = $this->common_model->get_records('report_log',array('assign_to_prepared_by'),array('report_log_seq'=>$report_seq),TRUE);
        $get_prepid = $get_username['assign_to_prepared_by'];
        $get_userdetails = $this->common_model->get_records('tbl_user',array('first_name'),array('user_id'=>$get_prepid),TRUE);
        $get_firstname = ($get_username['prepared_by_name']?$get_username['prepared_by_name']:$get_userdetails['first_name']);
$company_details=$this->common_model->get_records('tbl_company',array('company_name','company_address','company_logo'),'',TRUE);
$chamber_details=$this->common_model->get_records('chamber_master',array('Chamber_Name','Chamber_cd','report_type','no_of_temp_channel','no_of_humidity_channel'),array('chamber_seq'=>$chamber),TRUE);
$chambername=$chamber_details['Chamber_Name'];
$chambercode=$chamber_details['Chamber_cd'];
$report_type=$chamber_details['report_type'];
$tmpchannel = $chamber_details['no_of_temp_channel'];
$humchannel = $chamber_details['no_of_humidity_channel'];

if($report_type=="T"){
  $temp_channel_num = $tmpchannel/2;
 
$temp_channel_num_hum="";
}else{
$temp_channel_num_hum = $humchannel;
$temp_channel_num ="";
}
if($temp_channel_num > 8  )
{
    
$pdf = new MYPDFS('L', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
}else{
    
$pdf = new MYPDF('p', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
}

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('TMR');
$pdf->SetTitle('Scanner Offline Analysis');
$pdf->SetSubject('TMR');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');
$header_title=ucfirst($company_details['company_name']);
$address=nl2br($company_details['company_address']);
$header_string=<<<EOD
$address
Software Version :DAAS4.0
EOD;

// set font
$pdf->SetFont('helvetica', ' ', 9);
if($temp_channel_num == '2' )
{
  
  $fromdate= date('d-m-Y H:i:s',strtotime($from_date));
$todate= date('d-m-Y H:i:s',strtotime($to_date)); 

 $getstat = $this->common_model->get_records('historydb','',array('historydb_seq'=>'1'),'TRUE');
$get_detailstat_detailstat = $getstat['status'];

if(flagh == 0)
{
$txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}else{
    $txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td>Note: History Database</td></tr>
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}
$pdf->SetHeaderData('', PDF_HEADER_LOGO_WIDTH,$header_title,$txt);
$pdf->SetFont('helvetica', '', 9);
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

$pdf->SetAutoPageBreak(TRUE, 31);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}
$pdf->AddPage();
$pdf->SetFillColor(255, 255, 127);

$pdf->SetFillColor(255, 255, 215);
$tempbands = $this->common_model->get_records('channel_settings',array('temp_alarm_band','humidity_alarm_band'),array('chamber_seq'=>$chamber),'TRUE');		
 $tempalarmband=$tempbands['temp_alarm_band']==null ? "0.0" :$tempbands['temp_alarm_band'];
 $msHumidityBand=$tempbands['humidity_alarm_band']==null ? "0.0" :$tempbands['humidity_alarm_band'];
$tbl1 = <<<EOF
<style>
th{
	border: 0px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}
td {
  border: 0px solid black;
}
</style>
<table class="first" border="0" >
<thead>
<tr width="100%"><td colspan="2"><b>Temperature in  <sup>o</sup>C, Relative Humidity in %RH,Date and Time in DD-MM-YYYY HH:mm:ss,SV: Set Value</b></td></tr>
<tr><td colspan="2"><b>Note : "*" indicates values out of acceptance limit.</b></td></tr>
<tr><td width="100%"><b>Temperature Acceptance Limit ( <sup>o</sup>C):</b>+/- $tempalarmband </td></tr>
</thead>
</table>                   
EOF;
$pdf->writeHTML($tbl1,true, false, true, false, '');
$pdf->SetFillColor(255, 255, 215);
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
$to_date=date('Y-m-d H:i:s',strtotime($to_date));

$header_data=$this->temprature->get_header($chamber,$from_date,$to_date,$temp_channel_num);
$i=1;

foreach ($header_data as $value) {
	$channel=$value['CHANNEL'];
	 
	$mintemp=number_format((float)($value['TMINIMUM']), 1, '.', '');//round(,1);
	$maxtemp=number_format((float)($value['TMAXIMUM']), 1, '.', '');//round($value['TMAXIMUM'],1);
	$avgtemp=number_format((float)($value['TAVERAGE']), 1, '.', '');//round($value['TAVERAGE'],1);
	
$txt1 = <<<EOD
<table cellpadding="1" cellspacing="1"  >
<tr><td colspan="3"><b>$i) For Channel : $channel</b></td></tr>
<tr><td><b>Min Temperature: $mintemp</b> </td><td><b>Max Temperature: $maxtemp</b> </td><td><b>Avg Temperature: $avgtemp</b> </td></tr>

</table>                   
EOD;
$pdf->writeHTML($txt1);
$pdf->SetFillColor(255, 255, 215);
if($temp_channel_num==$i)
{
	break;
}
$i++;
}    
   
$html="";

	$this->db->select('Record_Date_Time');
	$this->db->where('scanner_details.Record_Date_Time >=',$from_date);
	$this->db->where('scanner_details.Record_Date_Time <=',$to_date);
	$this->db->where('scanner_details.chamber_seq',$chamber);
	$this->db->where("scanner_details.component_cd BETWEEN 'CH1' AND 'CH2'");
	$this->db->group_by('Record_Date_Time');	
	$this->db->order_by('Record_Date_Time','asc');
	//$this->db->limit('100');
	$query=$this->db->get('scanner_details');
	
	$data=$query->result_array();

	for($i=0;$i<count($data);$i++)
	{

	 $ch1=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH1','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch2=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH2','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $temp_hum= $this->temprature->get_sv($chamber,$data[$i]['Record_Date_Time']);
	
	 $ch1=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch1['Temperature_Value'],$tempalarmband);
	 $ch2=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch2['Temperature_Value'],$tempalarmband);
	 
	 $html.='<tr nobr="true">
	 <td align="center">'.date('d-m-Y H:i:00',strtotime($data[$i]['Record_Date_Time'])).'</td>
	 <td align="center">Temp</td>
	 <td align="center">'.number_format((float)($temp_hum['Temperature_setpoint']), 1, '.', '').'</td>
	 <td align="center">'.$ch1['Temperature_Value'].'</td>
	 <td align="center">'.$ch2['Temperature_Value'].'</td>
	 
	 </tr>';
	}

$tbl = <<<EOF
<style>

th{
	border: 1px solid black;
	font-weight:bold;
	background-color: #DCDCDC;
}
td {
  border: 1px solid black;
}
</style>
<table class="first" border="0" cellpadding="4" width="100%" >
<thead>
 <tr >
  <th align="center">Date/ Time</th>
  <th align="center"></th>
  <th align="center">SV</th>
  <th align="center">CH1</th>
  <th align="center">CH2</th>
  
 </tr>
 </thead>
	<tbody>
	$html
	</tbody>
</table>
EOF;

$rem="";

if($_GET['remark_id']!="")
{
    $rem="";
		 $remark_details=$_GET['remark_id'];
		 
$rem.='
<tr>
<td align="left" colspan="2">'.$remark_details.'</td></tr>
';
$tbl2= <<<EOF
<style>

th{
	border-bottom: 1px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}

table {
	border: 1px solid black;
	border-top: 3px solid black;
}

</style>
<table  cellpadding="3" >
<thead>
 <tr>
  <th>Remark</th>
  <th align="right" style="width:50%;">Username - $get_firstname</th>
 </tr>
</thead>
<tbody>
$rem
</tbody>
</table> 
EOF;
}else
{
   $tbl2= <<<EOF
EOF;
}

$pdf->writeHTML($tbl, true, false, true, false, '');
 
}

if($temp_channel_num == '4' )
{
  
  $fromdate= date('d-m-Y H:i:s',strtotime($from_date));
$todate= date('d-m-Y H:i:s',strtotime($to_date)); 

 $getstat = $this->common_model->get_records('historydb','',array('historydb_seq'=>'1'),'TRUE');
$get_detailstat_detailstat = $getstat['status'];

if(flagh == 0)
{
$txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}else{
    $txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td>Note: History Database</td></tr>
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}
$pdf->SetHeaderData('', PDF_HEADER_LOGO_WIDTH,$header_title,$txt);
$pdf->SetFont('helvetica', '', 9);
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

$pdf->SetAutoPageBreak(TRUE, 21);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}
$pdf->AddPage();
$pdf->SetFillColor(255, 255, 127);

$pdf->SetFillColor(255, 255, 215);
$tempbands = $this->common_model->get_records('channel_settings',array('temp_alarm_band','humidity_alarm_band'),array('chamber_seq'=>$chamber),'TRUE');		
 $tempalarmband=$tempbands['temp_alarm_band']==null ? "0.0" :$tempbands['temp_alarm_band'];
 $msHumidityBand=$tempbands['humidity_alarm_band']==null ? "0.0" :$tempbands['humidity_alarm_band'];
$tbl1 = <<<EOF
<style>
th{
	border: 0px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}
td {
  border: 0px solid black;
}
</style>
<table class="first" border="0" >
<thead>
<tr width="100%"><td colspan="2"><b>Temperature in  <sup>o</sup>C, Relative Humidity in %RH,Date and Time in DD-MM-YYYY HH:mm:ss,SV: Set Value</b></td></tr>
<tr><td colspan="2"><b>Note : "*" indicates values out of acceptance limit.</b></td></tr>
<tr><td width="100%"><b>Temperature Acceptance Limit ( <sup>o</sup>C):</b>+/- $tempalarmband </td></tr>
</thead>
</table>                   
EOF;
$pdf->writeHTML($tbl1,true, false, true, false, '');
$pdf->SetFillColor(255, 255, 215);
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
$to_date=date('Y-m-d H:i:s',strtotime($to_date));

$header_data=$this->temprature->get_header($chamber,$from_date,$to_date,$temp_channel_num);
$i=1;

foreach ($header_data as $value) {
	$channel=$value['CHANNEL'];
	$mintemp=number_format((float)($value['TMINIMUM']), 1, '.', '');//round($value['TMINIMUM'],1);
	$maxtemp=number_format((float)($value['TMAXIMUM']), 1, '.', '');//round($value['TMAXIMUM'],1);
	$avgtemp=number_format((float)($value['TAVERAGE']), 1, '.', '');//round($value['TAVERAGE'],1);
	
$txt1 = <<<EOD
<table cellpadding="1" cellspacing="1"  >
<tr><td colspan="3"><b>$i) For Channel : $channel</b></td></tr>
<tr><td><b>Min Temperature: $mintemp</b> </td><td><b>Max Temperature: $maxtemp</b> </td><td><b>Avg Temperature: $avgtemp</b> </td></tr>

</table>                   
EOD;
$pdf->writeHTML($txt1);
$pdf->SetFillColor(255, 255, 215);
if($temp_channel_num==$i)
{
	break;
}
$i++;
}    
   
$html="";

	$this->db->select('Record_Date_Time');
	$this->db->where('scanner_details.Record_Date_Time >=',$from_date);
	$this->db->where('scanner_details.Record_Date_Time <=',$to_date);
	$this->db->where('scanner_details.chamber_seq',$chamber);
	$this->db->where("scanner_details.component_cd BETWEEN 'CH1' AND 'CH4'");
	$this->db->group_by('Record_Date_Time');
	//$this->db->limit('100');
	$query=$this->db->get('scanner_details');
	
	$data=$query->result_array();

	for($i=0;$i<count($data);$i++)
	{

	 $ch1=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH1','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch2=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH2','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch3=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH3','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch4=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH4','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $temp_hum= $this->temprature->get_sv($chamber,$data[$i]['Record_Date_Time']);
	
	 $ch1=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch1['Temperature_Value'],$tempalarmband);
	 $ch2=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch2['Temperature_Value'],$tempalarmband);
	 $ch3=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch3['Temperature_Value'],$tempalarmband);
	 $ch4=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch4['Temperature_Value'],$tempalarmband);
	 $html.='<tr nobr="true" >
	 <td align="center">'.date('d-m-Y H:i:00',strtotime($data[$i]['Record_Date_Time'])).'</td>
	 <td align="center">Temp</td>
	 <td align="center">'.number_format((float)($temp_hum['Temperature_setpoint']), 1, '.', '').'</td>
	 <td align="center">'.$ch1['Temperature_Value'].'</td>
	 <td align="center">'.$ch2['Temperature_Value'].'</td>
	 <td align="center">'.$ch3['Temperature_Value'].'</td>
	<td align="center">'.$ch4['Temperature_Value'].'</td>
	 </tr>';
	}

$tbl = <<<EOF
<style>

th{
	border: 1px solid black;
	font-weight:bold;
	background-color: #DCDCDC;
}
td {
  border: 1px solid black;
}
</style>
<table class="first" border="0" cellpadding="4" width="100%" >
<thead>
 <tr >
  <th align="center">Date/ Time</th>
  <th align="center"></th>
  <th align="center">SV</th>
  <th align="center">CH1</th>
  <th align="center">CH2</th>
  <th align="center">CH3</th>
  <th align="center">CH4</th>
 </tr>
 </thead>
	<tbody>
	$html
	</tbody>
</table>
EOF;

$rem="";

if($_GET['remark_id']!="")
{
    $rem="";
		 $remark_details=$_GET['remark_id'];
		 
$rem.='
<tr>
<td align="left" colspan="2">'.$remark_details.'</td></tr>
';
$tbl2= <<<EOF
<style>

th{
	border-bottom: 1px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}

table {
	border: 1px solid black;
	border-top: 3px solid black;
}

</style>
<table  cellpadding="3" >
<thead>
 <tr>
  <th>Remark</th>
  <th align="right" style="width:50%;">Username - $get_firstname</th>
 </tr>
</thead>
<tbody>
$rem
</tbody>
</table> 
EOF;
}else
{
   $tbl2= <<<EOF
EOF;
}

$pdf->writeHTML($tbl, true, false, true, false, '');
 
}

if($temp_channel_num == '8')
    {
$fromdate= date('d-m-Y H:i:s',strtotime($from_date));
$todate= date('d-m-Y H:i:s',strtotime($to_date));
 $getstat = $this->common_model->get_records('historydb','',array('historydb_seq'=>'1'),'TRUE');
$get_detailstat = $getstat['status'];

if(flagh == 0)
{
$txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}else{
    $txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td>Note: History Database</td></tr>
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}
$pdf->SetHeaderData('', PDF_HEADER_LOGO_WIDTH,$header_title,$txt);
$pdf->SetFont('helvetica', '', 9);
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

$pdf->SetAutoPageBreak(TRUE, 21);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}
$pdf->AddPage();
$pdf->SetFillColor(255, 255, 127);

$pdf->SetFillColor(255, 255, 215);
$tempbands = $this->common_model->get_records('channel_settings',array('temp_alarm_band','humidity_alarm_band'),array('chamber_seq'=>$chamber),'TRUE');		
 $tempalarmband=$tempbands['temp_alarm_band']==null ? "0.0" :$tempbands['temp_alarm_band'];
 $msHumidityBand=$tempbands['humidity_alarm_band']==null ? "0.0" :$tempbands['humidity_alarm_band'];
$tbl1 = <<<EOF
<style>
th{
	border: 0px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}
td {
  border: 0px solid black;
}
</style>
<table class="first" border="0" >
<tr width="99%"><td colspan="2"><b>Temperature in  <sup>o</sup>C, Relative Humidity in %RH, SV: Set Value, Min: Minimum, Max: Maximum, Avg: Average, CH:Channel</b></td></tr>
<tr><td colspan="2"><b>Note : "*" indicates values out of acceptance limit.</b></td></tr>
<tr><td width="100%"><b>Temperature Acceptance Limit ( <sup>o</sup>C):</b>+/- $tempalarmband </td></tr>
</table>                   
EOF;
$pdf->writeHTML($tbl1,true, false, true, false, '');
$pdf->SetFillColor(255, 255, 215);
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
$to_date=date('Y-m-d H:i:s',strtotime($to_date));

$header_data=$this->temprature->get_header($chamber,$from_date,$to_date,$temp_channel_num);
$i=1;

foreach ($header_data as $value) {
	$channel=$value['CHANNEL'];
	$mintemp=number_format((float)($value['TMINIMUM']), 1, '.', '');//round($value['TMINIMUM'],1);
	$maxtemp=number_format((float)($value['TMAXIMUM']), 1, '.', '');//round($value['TMAXIMUM'],1);
	$avgtemp=number_format((float)($value['TAVERAGE']), 1, '.', '');//round($value['TAVERAGE'],1);
	
$txt1 = <<<EOD
<table cellpadding="1" cellspacing="1"  >
<tr><td colspan="3"><b>$i) For Channel : $channel</b></td></tr>
<tr><td><b>Min Temperature: $mintemp</b> </td><td><b>Max Temperature: $maxtemp</b> </td><td><b>Avg Temperature: $avgtemp</b> </td></tr>

</table>                   
EOD;
$pdf->writeHTML($txt1);
$pdf->SetFillColor(255, 255, 215);
if($temp_channel_num==$i)
{
	break;
}
$i++;
}
    
        
   
    $html="";
// Table with rowspans and THEAD
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
 $to_date=date('Y-m-d H:i:s',strtotime( $to_date));
	$this->db->select('Record_Date_Time');
	$this->db->where('scanner_details.Record_Date_Time >=',$from_date);
	$this->db->where('scanner_details.Record_Date_Time <=',$to_date);
	$this->db->where('scanner_details.chamber_seq',$chamber);
	$this->db->where("scanner_details.component_cd BETWEEN 'CH1' AND 'CH8'");
	$this->db->group_by('Record_Date_Time');
	$query=$this->db->get('scanner_details');
	$data=$query->result_array();


for($i=0;$i<count($data);$i++)
{
	 $ch1=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH1','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch2=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH2','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch3=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH3','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch4=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH4','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch5=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH5','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch6=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH6','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch7=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH7','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch8=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH8','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $temp_hum= $this->temprature->get_sv($chamber,$data[$i]['Record_Date_Time']);
	 $ch1=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch1['Temperature_Value'],$tempalarmband);
	 $ch2=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch2['Temperature_Value'],$tempalarmband);
	 $ch3=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch3['Temperature_Value'],$tempalarmband);
	 $ch4=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch4['Temperature_Value'],$tempalarmband);
	 $ch5=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch5['Temperature_Value'],$tempalarmband);
	 $ch6=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch6['Temperature_Value'],$tempalarmband);
	 $ch7=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch7['Temperature_Value'],$tempalarmband);
	 $ch8=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch8['Temperature_Value'],$tempalarmband);
 $html.='<tr nobr="true">
 <td style="width:25%">'.date('d-m-Y H:i:00',strtotime($data[$i]['Record_Date_Time'])).'</td>
 <td style="width:7%">Temp</td>
 	 <td style="width:7%">'.number_format((float)($temp_hum['Temperature_setpoint']), 1, '.', '').'</td>
	 <td style="width:7%">'.$ch1['Temperature_Value'].'</td>
	 <td style="width:7%">'.$ch2['Temperature_Value'].'</td>
	 <td style="width:7%">'.$ch3['Temperature_Value'].'</td>
	 <td style="width:7%">'.$ch4['Temperature_Value'].'</td>
	 <td style="width:7%">'.$ch5['Temperature_Value'].'</td>
	 <td style="width:7%">'.$ch6['Temperature_Value'].'</td>
	 <td style="width:7%">'.$ch7['Temperature_Value'].'</td>
	 <td style="width:7%">'.$ch8['Temperature_Value'].'</td>
 </tr>';
}

$tbl = <<<EOF
<style>

th{
	border: 1px solid black;
	font-weight:bold;
	background-color: #DCDCDC;
}
td {
  border: 1px solid black;
}
</style>
<table class="first" border="0" cellpadding="4" max-width="100%" >
<thead>

 <tr>
  <th style="width:25%">Date/ Time</th>
  <th style="width:7%"></th>
  <th style="width:7%">SV</th>
  <th style="width:7%">CH1</th>
  <th style="width:7%">CH2</th>
  <th style="width:7%">CH3</th>
  <th style="width:7%">CH4</th>
  <th style="width:7%">CH5</th>
  <th style="width:7%">CH6</th>
  <th style="width:7%">CH7</th>
 <th style="width:7%">CH8</th>
 </tr>
 </thead>
 <tbody>
 $html
 </tbody>
</table>
EOF;

$rem="";

if( $_GET['remark_id']!="")
{
    $rem="";
		 $remark_details=$_GET['remark_id'];
		 
$rem.='
<tr>
<td align="left" colspan="2">'.$remark_details.'</td></tr>
';
$tbl2= <<<EOF
<style>

th{
	border-bottom: 1px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}

table {
	border: 1px solid black;
	border-top: 3px solid black;
}

</style>
</style>
<table  cellpadding="3" >
<thead>
 <tr>
  <th>Remark</th>
  <th align="right" style="width:50%;">Username - $get_firstname</th>
 </tr>
</thead>
<tbody>
$rem
</tbody>
</table> 
EOF;
}else
{
   $tbl2= <<<EOF
EOF;
}

$pdf->writeHTML($tbl, true, false, true, false, '');

    
    }

if($temp_channel_num == '9')
{
    $fromdate= date('d-m-Y H:i:s',strtotime($from_date));
$todate= date('d-m-Y H:i:s',strtotime($to_date));
 $getstat = $this->common_model->get_records('historydb','',array('historydb_seq'=>'1'),'TRUE');
$get_detailstat = $getstat['status'];

if(flagh == 0)
{
$txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}else{
    $txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td>Note: History Database</td></tr>
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}
$pdf->SetHeaderData('', PDF_HEADER_LOGO_WIDTH,$header_title,$txt);
$pdf->SetFont('helvetica', '', 9);
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

$pdf->SetAutoPageBreak(TRUE, 21);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}
$pdf->AddPage();
$pdf->SetFillColor(255, 255, 127);

$pdf->SetFillColor(255, 255, 215);
$tempbands = $this->common_model->get_records('channel_settings',array('temp_alarm_band','humidity_alarm_band'),array('chamber_seq'=>$chamber),'TRUE');		
 $tempalarmband=$tempbands['temp_alarm_band']==null ? "0.0" :$tempbands['temp_alarm_band'];
 $msHumidityBand=$tempbands['humidity_alarm_band']==null ? "0.0" :$tempbands['humidity_alarm_band'];
$tbl1 = <<<EOF
<style>
th{
	border: 0px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}
td {
  border: 0px solid black;
}
</style>
<table class="first" border="0">
<tr width="99%"><td colspan="2"><b>Temperature in  <sup>o</sup>C, Relative Humidity in %RH, SV: Set Value, Min: Minimum, Max: Maximum, Avg: Average, CH:Channel</b></td></tr>
<tr><td colspan="2"><b>Note : "*" indicates values out of acceptance limit.</b></td></tr>
<tr><td width="100%"><b>Temperature Acceptance Limit ( <sup>o</sup>C):</b>+/- $tempalarmband </td></tr>
</table>                   
EOF;
$pdf->writeHTML($tbl1,true, false, true, false, '');
$pdf->SetFillColor(255, 255, 215);
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
$to_date=date('Y-m-d H:i:s',strtotime($to_date));

$header_data=$this->temprature->get_header($chamber,$from_date,$to_date,$temp_channel_num);
$i=1;

foreach ($header_data as $value) {
	$channel=$value['CHANNEL'];
	$mintemp=number_format((float)($value['TMINIMUM']), 1, '.', '');//round($value['TMINIMUM'],1);
	$maxtemp=number_format((float)($value['TMAXIMUM']), 1, '.', '');//round($value['TMAXIMUM'],1);
	$avgtemp=number_format((float)($value['TAVERAGE']), 1, '.', '');//round($value['TAVERAGE'],1);
	
$txt1 = <<<EOD
<table cellpadding="1" cellspacing="1"  >
<tr><td colspan="3"><b>$i) For Channel : $channel</b></td></tr>
<tr><td><b>Min Temperature: $mintemp</b> </td><td><b>Max Temperature: $maxtemp</b> </td><td><b>Avg Temperature: $avgtemp</b> </td></tr>

</table>                   
EOD;
$pdf->writeHTML($txt1);
$pdf->SetFillColor(255, 255, 215);
if($temp_channel_num==$i)
{
	break;
}
$i++;
}
    $html="";
// Table with rowspans and THEAD
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
 $to_date=date('Y-m-d H:i:s',strtotime( $to_date));
	$this->db->select('Record_Date_Time');
	$this->db->where('scanner_details.Record_Date_Time >=',$from_date);
	$this->db->where('scanner_details.Record_Date_Time <=',$to_date);
	$this->db->where('scanner_details.chamber_seq',$chamber);
	$this->db->where("scanner_details.component_cd BETWEEN 'CH1' AND 'CH9'");
	$this->db->group_by('Record_Date_Time');
	$query=$this->db->get('scanner_details');
	$data=$query->result_array();


for($i=0;$i<count($data);$i++)
{
	 $ch1=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH1','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch2=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH2','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch3=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH3','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch4=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH4','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch5=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH5','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch6=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH6','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch7=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH7','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch8=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH8','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch9=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH9','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $temp_hum= $this->temprature->get_sv($chamber,$data[$i]['Record_Date_Time']);
	 $ch1=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch1['Temperature_Value'],$tempalarmband);
	 $ch2=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch2['Temperature_Value'],$tempalarmband);
	 $ch3=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch3['Temperature_Value'],$tempalarmband);
	 $ch4=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch4['Temperature_Value'],$tempalarmband);
	 $ch5=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch5['Temperature_Value'],$tempalarmband);
	 $ch6=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch6['Temperature_Value'],$tempalarmband);
	 $ch7=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch7['Temperature_Value'],$tempalarmband);
	 $ch8=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch8['Temperature_Value'],$tempalarmband);
	 $ch9=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch9['Temperature_Value'],$tempalarmband);
 $html.='<tr nobr="true" >
 <td align="center" style="width:25%">'.date('d-m-Y H:i:00',strtotime($data[$i]['Record_Date_Time'])).'</td>
 <td align="center" style="width:7%">Temp </td>
 	 <td align="center" style="width:7%">'.number_format((float)($temp_hum['Temperature_setpoint']), 1, '.', '').'</td>
	 <td align="center" style="width:7%">'.$ch1['Temperature_Value'].' </td>
	 <td align="center" style="width:7%">'.$ch2['Temperature_Value'].'</td>
	 <td align="center" style="width:7%">'.$ch3['Temperature_Value'].'</td>
	 <td align="center" style="width:7%">'.$ch4['Temperature_Value'].'</td>
	 <td align="center" style="width:7%">'.$ch5['Temperature_Value'].'</td>
	 <td align="center" style="width:7%">'.$ch6['Temperature_Value'].'</td>
	 <td align="center"  style="width:7%">'.$ch7['Temperature_Value'].'</td>
	 <td align="center"  style="width:7%">'.$ch8['Temperature_Value'].'</td>
	 <td align="center"  style="width:7%">'.$ch9['Temperature_Value'].'</td>
 </tr>';
}

$tbl = <<<EOF
<style>

th{
	border: 1px solid black;
	font-weight:bold;
	background-color: #DCDCDC;
}
td {
  border: 1px solid black;
}
</style>
<table class="first" border="0" cellpadding="4" max-width="100%" >
<thead>

 <tr>
  <th align="center" style="width:25%">Date/ Time</th>
  <th align="center" style="width:7%"></th>
  <th align="center" style="width:7%">SV</th>
  <th align="center" style="width:7%">CH1</th>
  <th align="center" style="width:7%">CH2</th>
  <th align="center" style="width:7%">CH3</th>
  <th align="center" style="width:7%">CH4</th>
  <th align="center" style="width:7%">CH5</th>
  <th align="center" style="width:7%">CH6</th>
  <th align="center" style="width:7%">CH7</th>
 <th align="center"  style="width:7%">CH8</th>
  <th align="center"  style="width:7%">CH9</th>
 </tr>
 </thead>
 <tbody>
 $html
 </tbody>
</table>
EOF;

$rem="";

if( $_GET['remark_id']!="")
{
    $rem="";
		 $remark_details=$_GET['remark_id'];
		 
$rem.='
<tr>
<td align="left" colspan="2">'.$remark_details.'</td></tr>
';
$tbl2= <<<EOF
<style>

th{
	border-bottom: 1px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}

table {
	border: 1px solid black;
	border-top: 3px solid black;
}

</style>
<table  cellpadding="3" >
<thead>
 <tr>
  <th>Remark</th>
  <th align="right" style="width:50%;">Username - $get_firstname</th>
 </tr>
</thead>
<tbody>
$rem
</tbody>
</table> 
EOF;
}else
{
   $tbl2= <<<EOF
EOF;
}
$pdf->writeHTML($tbl, true, false, true, false, '');


}

if($temp_channel_num == '12')
{
    $fromdate= date('d-m-Y H:i:s',strtotime($from_date));
$todate= date('d-m-Y H:i:s',strtotime($to_date));
 $getstat = $this->common_model->get_records('historydb','',array('historydb_seq'=>'1'),'TRUE');
$get_detailstat = $getstat['status'];

if(flagh == 0)
{
$txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}else{
    $txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td>Note: History Database</td></tr>
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}
$pdf->SetHeaderData('', PDF_HEADER_LOGO_WIDTH,$header_title,$txt);
$pdf->SetFont('helvetica', '', 9);
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

$pdf->SetAutoPageBreak(TRUE, 21);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}
$pdf->AddPage();
$pdf->SetFillColor(255, 255, 127);

$pdf->SetFillColor(255, 255, 215);
$tempbands = $this->common_model->get_records('channel_settings',array('temp_alarm_band','humidity_alarm_band'),array('chamber_seq'=>$chamber),'TRUE');		
 $tempalarmband=$tempbands['temp_alarm_band']==null ? "0.0" :$tempbands['temp_alarm_band'];
 $msHumidityBand=$tempbands['humidity_alarm_band']==null ? "0.0" :$tempbands['humidity_alarm_band'];
$tbl1 = <<<EOF
<style>
th{
	border: 0px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}
td {
  border: 0px solid black;
}
</style>
<table class="first" border="0" >
<thead>
<tr width="99%"><td colspan="2"><b>Temperature in  <sup>o</sup>C, Relative Humidity in %RH, SV: Set Value, Min: Minimum, Max: Maximum, Avg: Average, CH:Channel</b></td></tr>
<tr><td colspan="2"><b>Note : "*" indicates values out of acceptance limit.</b></td></tr>
<tr><td width="100%" colspan="2"><b>Temperature Acceptance Limit ( <sup>o</sup>C):</b>+/- $tempalarmband </td></tr>
</thead>
</table>                   
EOF;
$pdf->writeHTML($tbl1,true, false, true, false, '');
$pdf->SetFillColor(255, 255, 215);
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
$to_date=date('Y-m-d H:i:s',strtotime($to_date));

$header_data=$this->temprature->get_header($chamber,$from_date,$to_date,$temp_channel_num);
$i=1;

foreach ($header_data as $value) {
	$channel=$value['CHANNEL'];
	$mintemp=number_format((float)($value['TMINIMUM']), 1, '.', '');//round($value['TMINIMUM'],1);
	$maxtemp=number_format((float)($value['TMAXIMUM']), 1, '.', '');//round($value['TMAXIMUM'],1);
	$avgtemp=number_format((float)($value['TAVERAGE']), 1, '.', '');//round($value['TAVERAGE'],1);
	
$txt1 = <<<EOD
<table cellpadding="1" cellspacing="1"  >
<tr><td colspan="3"><b>$i) For Channel : $channel</b></td></tr>
<tr><td><b>Min Temperature: $mintemp</b> </td><td><b>Max Temperature: $maxtemp</b> </td><td><b>Avg Temperature: $avgtemp</b> </td></tr>

</table>                   
EOD;
$pdf->writeHTML($txt1);
$pdf->SetFillColor(255, 255, 215);
if($temp_channel_num==$i)
{
	break;
}
$i++;
}
    $html="";
// Table with rowspans and THEAD
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
 $to_date=date('Y-m-d H:i:s',strtotime( $to_date));
	$this->db->select('Record_Date_Time');
	$this->db->where('scanner_details.Record_Date_Time >=',$from_date);
	$this->db->where('scanner_details.Record_Date_Time <=',$to_date);
	$this->db->where('scanner_details.chamber_seq',$chamber);
	$this->db->where("scanner_details.component_cd BETWEEN 'CH1' AND 'CH12'");
	$this->db->group_by('Record_Date_Time');
	$query=$this->db->get('scanner_details');
	$data=$query->result_array();


for($i=0;$i<count($data);$i++)
{
	 $ch1=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH1','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch2=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH2','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch3=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH3','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch4=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH4','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch5=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH5','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch6=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH6','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch7=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH7','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch8=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH8','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch9=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH9','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch10=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH10','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch11=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH11','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch12=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH12','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $temp_hum= $this->temprature->get_sv($chamber,$data[$i]['Record_Date_Time']);
	 $ch1=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch1['Temperature_Value'],$tempalarmband);
	 $ch2=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch2['Temperature_Value'],$tempalarmband);
	 $ch3=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch3['Temperature_Value'],$tempalarmband);
	 $ch4=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch4['Temperature_Value'],$tempalarmband);
	 $ch5=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch5['Temperature_Value'],$tempalarmband);
	 $ch6=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch6['Temperature_Value'],$tempalarmband);
	 $ch7=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch7['Temperature_Value'],$tempalarmband);
	 $ch8=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch8['Temperature_Value'],$tempalarmband);
	 $ch9=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch9['Temperature_Value'],$tempalarmband);
	 $ch10=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch10['Temperature_Value'],$tempalarmband);
	 $ch11=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch11['Temperature_Value'],$tempalarmband);
	 $ch12=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch12['Temperature_Value'],$tempalarmband);
 $html.='<tr nobr="true">
 <td align="center" style="width:20%">'.date('d-m-Y H:i:00',strtotime($data[$i]['Record_Date_Time'])).'</td>
 <td align="center" style="width:5%">Temp</td>
 	 <td align="center" style="width:5%">'.number_format((float)($temp_hum['Temperature_setpoint']), 1, '.', '').'</td>
	 <td align="center" style="width:5%">'.$ch1['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch2['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch3['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch4['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch5['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch6['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch7['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch8['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch9['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch10['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch11['Temperature_Value'].' </td>
	 <td align="center"  style="width:5%">'.$ch12['Temperature_Value'].' </td>
 </tr>';
}

$tbl = <<<EOF
<style>

th{
	border: 1px solid black;
	font-weight:bold;
	background-color: #DCDCDC;
}
td {
  border: 1px solid black;
}
</style>
<table class="first" border="0" cellpadding="4" max-width="100%" >
<thead>

 <tr>
  <th align="center" style="width:20%">Date/ Time</th>
  <th align="center" style="width:5%"></th>
  <th align="center" style="width:5%">SV</th>
  <th align="center" style="width:5%">CH1</th>
  <th align="center" style="width:5%">CH2</th>
  <th align="center" style="width:5%">CH3</th>
  <th align="center" style="width:5%">CH4</th>
  <th align="center" style="width:5%">CH5</th>
  <th align="center" style="width:5%">CH6</th>
  <th align="center" style="width:5%">CH7</th>
  <th align="center" style="width:5%">CH8</th>
  <th align="center" style="width:5%">CH9</th>
  <th align="center" style="width:5%">CH10</th>
  <th align="center" style="width:5%">CH11</th>
  <th align="center"  style="width:5%">CH12</th>
 </tr>
 </thead>
 <tbody>
 $html
 </tbody>
</table>
EOF;

$rem="";

if( $_GET['remark_id']!="")
{
    $rem="";
		 $remark_details=$_GET['remark_id'];
		 
$rem.='
<tr>
<td align="left" colspan="2">'.$remark_details.'</td></tr>
';
$tbl2= <<<EOF
<style>

th{
	border-bottom: 1px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}

table {
	border: 1px solid black;
	border-top: 3px solid black;
}

</style>
<table  cellpadding="3" >
<thead>
 <tr>
  <th>Remark</th>
  <th align="right" style="width:50%;">Username - $get_firstname</th>
 </tr>
</thead>
<tbody>
$rem
</tbody>
</table> 
EOF;
}else
{
   $tbl2= <<<EOF

EOF;
}

$pdf->writeHTML($tbl, true, false, true, false, '');
}
if($temp_channel_num == '14')
{
    $fromdate= date('d-m-Y H:i:s',strtotime($from_date));
$todate= date('d-m-Y H:i:s',strtotime($to_date));
                 $getstat = $this->common_model->get_records('historydb','',array('historydb_seq'=>'1'),'TRUE');
$get_detailstat = $getstat['status'];

if(flagh == 0)
{
$txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}else{
    $txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td>Note: History Database</td></tr>
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}
$pdf->SetHeaderData('', PDF_HEADER_LOGO_WIDTH,$header_title,$txt);
$pdf->SetFont('helvetica', '', 9);
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

$pdf->SetAutoPageBreak(TRUE, 21);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}
$pdf->AddPage();
$pdf->SetFillColor(255, 255, 127);

$pdf->SetFillColor(255, 255, 215);
$tempbands = $this->common_model->get_records('channel_settings',array('temp_alarm_band','humidity_alarm_band'),array('chamber_seq'=>$chamber),'TRUE');		
 $tempalarmband=$tempbands['temp_alarm_band']==null ? "0.0" :$tempbands['temp_alarm_band'];
 $msHumidityBand=$tempbands['humidity_alarm_band']==null ? "0.0" :$tempbands['humidity_alarm_band'];
$tbl1 = <<<EOF
<style>
th{
	border: 0px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}
td {
  border: 0px solid black;
}
</style>
<table class="first" border="0" >
<tr width="99%"><td colspan="2"><b>Temperature in  <sup>o</sup>C, Relative Humidity in %RH,SV: Set Value, Min: Minimum, Max: Maximum, Avg: Average, CH:Channel</b></td></tr>
<tr><td colspan="2"><b>Note : "*" indicates values out of acceptance limit.</b></td></tr>
<tr><td width="100%"><b>Temperature Acceptance Limit ( <sup>o</sup>C):</b>+/- $tempalarmband </td></tr>
</table>                   
EOF;
$pdf->writeHTML($tbl1,true, false, true, false, '');
$pdf->SetFillColor(255, 255, 215);
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
$to_date=date('Y-m-d H:i:s',strtotime($to_date));

$header_data=$this->temprature->get_header($chamber,$from_date,$to_date,$temp_channel_num);
$i=1;

foreach ($header_data as $value) {
	$channel=$value['CHANNEL'];
	$mintemp=number_format((float)($value['TMINIMUM']), 1, '.', '');//round($value['TMINIMUM'],1);
	$maxtemp=number_format((float)($value['TMAXIMUM']), 1, '.', '');//round($value['TMAXIMUM'],1);
	$avgtemp=number_format((float)($value['TAVERAGE']), 1, '.', '');//round($value['TAVERAGE'],1);
	
$txt1 = <<<EOD
<table cellpadding="1" cellspacing="1"  >
<tr><td colspan="3"><b>$i) For Channel : $channel</b></td></tr>
<tr><td><b>Min Temperature: $mintemp</b> </td><td><b>Max Temperature: $maxtemp</b> </td><td><b>Avg Temperature: $avgtemp</b> </td></tr>

</table>                   
EOD;
$pdf->writeHTML($txt1);
$pdf->SetFillColor(255, 255, 215);
if($temp_channel_num==$i)
{
	break;
}
$i++;
}
    $html="";
// Table with rowspans and THEAD
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
 $to_date=date('Y-m-d H:i:s',strtotime( $to_date));
	$this->db->select('Record_Date_Time');
	$this->db->where('scanner_details.Record_Date_Time >=',$from_date);
	$this->db->where('scanner_details.Record_Date_Time <=',$to_date);
	$this->db->where('scanner_details.chamber_seq',$chamber);
	$this->db->where("scanner_details.component_cd BETWEEN 'CH1' AND 'CH14'");
	$this->db->group_by('Record_Date_Time');
	$query=$this->db->get('scanner_details');
	$data=$query->result_array();


for($i=0;$i<count($data);$i++)
{
	 $ch1=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH1','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch2=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH2','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch3=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH3','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch4=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH4','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch5=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH5','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch6=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH6','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch7=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH7','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch8=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH8','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch9=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH9','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch10=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH10','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch11=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH11','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch12=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH12','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch13=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH13','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch14=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH14','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $temp_hum= $this->temprature->get_sv($chamber,$data[$i]['Record_Date_Time']);
	 $ch1=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch1['Temperature_Value'],$tempalarmband);
	 $ch2=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch2['Temperature_Value'],$tempalarmband);
	 $ch3=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch3['Temperature_Value'],$tempalarmband);
	 $ch4=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch4['Temperature_Value'],$tempalarmband);
	 $ch5=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch5['Temperature_Value'],$tempalarmband);
	 $ch6=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch6['Temperature_Value'],$tempalarmband);
	 $ch7=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch7['Temperature_Value'],$tempalarmband);
	 $ch8=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch8['Temperature_Value'],$tempalarmband);
	 $ch9=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch9['Temperature_Value'],$tempalarmband);
	 $ch10=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch10['Temperature_Value'],$tempalarmband);
	 $ch11=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch11['Temperature_Value'],$tempalarmband);
	 $ch12=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch12['Temperature_Value'],$tempalarmband);
	 $ch13=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch13['Temperature_Value'],$tempalarmband);
	 $ch14=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch14['Temperature_Value'],$tempalarmband);
 $html.='<tr nobr="true">
 <td align="center" style="width:15%">'.date('d-m-Y H:i:00',strtotime($data[$i]['Record_Date_Time'])).'</td>
 <td align="center" style="width:5%">Temp</td>
 	  <td align="center" style="width:5%">'.number_format((float)($temp_hum['Temperature_setpoint']), 1, '.', '').'</td>
	 <td align="center" style="width:5%">'.$ch1['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch2['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch3['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch4['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch5['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch6['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch7['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch8['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch9['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch10['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch11['Temperature_Value'].' </td>
	 <td align="center"  style="width:5%">'.$ch12['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch13['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch14['Temperature_Value'].' </td>
 </tr>';
}

$tbl = <<<EOF
<style>

th{
	border: 1px solid black;
	font-weight:bold;
	background-color: #DCDCDC;
}
td {
  border: 1px solid black;
}
</style>
<table class="first" border="0" cellpadding="4" max-width="100%" >
<thead>

 <tr>
  <th align="center" style="width:15%">Date/ Time</th>
  <th align="center" style="width:5%"></th>
  <th align="center" style="width:5%">SV</th>
  <th align="center" style="width:5%">CH1</th>
  <th align="center" style="width:5%">CH2</th>
  <th align="center" style="width:5%">CH3</th>
  <th align="center" style="width:5%">CH4</th>
  <th align="center" style="width:5%">CH5</th>
  <th align="center" style="width:5%">CH6</th>
  <th align="center" style="width:5%">CH7</th>
  <th align="center" style="width:5%">CH8</th>
  <th align="center" style="width:5%">CH9</th>
  <th align="center" style="width:5%">CH10</th>
  <th align="center" style="width:5%">CH11</th>
  <th align="center" style="width:5%">CH12</th>
  <th align="center" style="width:5%">CH13</th>
  <th align="center" style="width:5%">CH14</th>

 </tr>
 </thead>
 <tbody>
 $html
 </tbody>
</table>
EOF;

$rem="";

if( $_GET['remark_id']!="")
{
    $rem="";
		 $remark_details=$_GET['remark_id'];
		 
$rem.='
<tr>
<td align="left" colspan="2">'.$remark_details.'</td></tr>
';
$tbl2= <<<EOF
<style>

th{
	border-bottom: 1px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}

table {
	border: 1px solid black;
	border-top: 3px solid black;
}

</style>
<table  cellpadding="3" >
<thead>
 <tr>
  <th>Remark</th>
  <th align="right" style="width:50%;">Username - $get_firstname</th>
 </tr>
</thead>
<tbody>
$rem
</tbody>
</table> 
EOF;
}else
{
   $tbl2= <<<EOF

EOF;
}

$pdf->writeHTML($tbl, true, false, true, false, '');
}
if($temp_channel_num == '16')
{
    $fromdate= date('d-m-Y H:i:s',strtotime($from_date));
$todate= date('d-m-Y H:i:s',strtotime($to_date));
               $getstat = $this->common_model->get_records('historydb','',array('historydb_seq'=>'1'),'TRUE');
$get_detailstat = $getstat['status'];

if(flagh == 0)
{
$txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}else{
    $txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td>Note: History Database</td></tr>
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}
$pdf->SetHeaderData('', PDF_HEADER_LOGO_WIDTH,$header_title,$txt);
$pdf->SetFont('helvetica', '', 9);
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

$pdf->SetAutoPageBreak(TRUE, 21);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}
$pdf->AddPage();
$pdf->SetFillColor(255, 255, 127);

$pdf->SetFillColor(255, 255, 215);
$tempbands = $this->common_model->get_records('channel_settings',array('temp_alarm_band','humidity_alarm_band'),array('chamber_seq'=>$chamber),'TRUE');		
 $tempalarmband=$tempbands['temp_alarm_band']==null ? "0.0" :$tempbands['temp_alarm_band'];
 $msHumidityBand=$tempbands['humidity_alarm_band']==null ? "0.0" :$tempbands['humidity_alarm_band'];
$tbl1 = <<<EOF
<style>
th{
	border: 0px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}
td {
  border: 0px solid black;
}
</style>
<table class="first" border="0" >
<tr width="99%"><td colspan="2"><b>Temperature in  <sup>o</sup>C, Relative Humidity in %RH, SV: Set Value, Min: Minimum, Max: Maximum, Avg: Average, CH:Channel</b></td></tr>
<tr><td colspan="2"><b>Note : "*" indicates values out of acceptance limit.</b></td></tr>
<tr><td width="100%"><b>Temperature Acceptance Limit ( <sup>o</sup>C):</b>+/- $tempalarmband </td></tr>
</table>                   
EOF;
$pdf->writeHTML($tbl1,true, false, true, false, '');
$pdf->SetFillColor(255, 255, 215);
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
$to_date=date('Y-m-d H:i:s',strtotime($to_date));

$header_data=$this->temprature->get_header($chamber,$from_date,$to_date,$temp_channel_num);
$i=1;

foreach ($header_data as $value) {
	$channel=$value['CHANNEL'];
	$mintemp=number_format((float)($value['TMINIMUM']), 1, '.', '');//round($value['TMINIMUM'],1);
	$maxtemp=number_format((float)($value['TMAXIMUM']), 1, '.', '');//round($value['TMAXIMUM'],1);
	$avgtemp=number_format((float)($value['TAVERAGE']), 1, '.', '');//round($value['TAVERAGE'],1);
	
$txt1 = <<<EOD
<table cellpadding="1" cellspacing="1"  >
<tr><td colspan="3"><b>$i) For Channel : $channel</b></td></tr>
<tr><td><b>Min Temperature: $mintemp</b> </td><td><b>Max Temperature: $maxtemp</b> </td><td><b>Avg Temperature: $avgtemp</b> </td></tr>

</table>                   
EOD;
$pdf->writeHTML($txt1);
$pdf->SetFillColor(255, 255, 215);
if($temp_channel_num==$i)
{
	break;
}
$i++;
}
    $html="";
// Table with rowspans and THEAD
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
 $to_date=date('Y-m-d H:i:s',strtotime( $to_date));
	$this->db->select('Record_Date_Time');
	$this->db->where('scanner_details.Record_Date_Time >=',$from_date);
	$this->db->where('scanner_details.Record_Date_Time <=',$to_date);
	$this->db->where('scanner_details.chamber_seq',$chamber);
	$this->db->where("scanner_details.component_cd BETWEEN 'CH1' AND 'CH16'");
	$this->db->group_by('Record_Date_Time');
	$query=$this->db->get('scanner_details');
	$data=$query->result_array();

for($i=0;$i<count($data);$i++)
{
	$ch1=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH1','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch2=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH2','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch3=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH3','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch4=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH4','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch5=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH5','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch6=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH6','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch7=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH7','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch8=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH8','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch9=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH9','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch10=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH10','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch11=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH11','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch12=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH12','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch13=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH13','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch14=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH14','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch15=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH15','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch16=$this->common_model->get_records('scanner_details',array('Temperature_Value'),array('component_cd'=>'CH16','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $temp_hum= $this->temprature->get_sv($chamber,$data[$i]['Record_Date_Time']);
	 $ch1=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch1['Temperature_Value'],$tempalarmband);
	 $ch2=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch2['Temperature_Value'],$tempalarmband);
	 $ch3=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch3['Temperature_Value'],$tempalarmband);
	 $ch4=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch4['Temperature_Value'],$tempalarmband);
	 $ch5=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch5['Temperature_Value'],$tempalarmband);
	 $ch6=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch6['Temperature_Value'],$tempalarmband);
	 $ch7=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch7['Temperature_Value'],$tempalarmband);
	 $ch8=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch8['Temperature_Value'],$tempalarmband);
	 $ch9=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch9['Temperature_Value'],$tempalarmband);
	 $ch10=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch10['Temperature_Value'],$tempalarmband);
	 $ch11=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch11['Temperature_Value'],$tempalarmband);
	 $ch12=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch12['Temperature_Value'],$tempalarmband);
	 $ch13=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch13['Temperature_Value'],$tempalarmband);
	 $ch14=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch14['Temperature_Value'],$tempalarmband);
	 $ch15=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch15['Temperature_Value'],$tempalarmband);
	 $ch16=$this->Checkdata1($temp_hum['Temperature_setpoint'],$ch16['Temperature_Value'],$tempalarmband);
 $html.='<tr nobr="true" >
 <td align="center" style="width:12%">'.date('d-m-Y H:i:00',strtotime($data[$i]['Record_Date_Time'])).'</td>
 <td align="center" style="width:5%">Temp</td>
 	<td align="center" style="width:5%">'.number_format((float)($temp_hum['Temperature_setpoint']), 1, '.', '').'</td>
	 <td align="center" style="width:5%">'.$ch1['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch2['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch3['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch4['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch5['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch6['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch7['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch8['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch9['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch10['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch11['Temperature_Value'].' </td>
	 <td align="center"  style="width:5%">'.$ch12['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch13['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch14['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch15['Temperature_Value'].' </td>
	 <td align="center" style="width:5%">'.$ch16['Temperature_Value'].' </td>
 </tr>';
}
$tbl = <<<EOF
<style>

th{
	border: 1px solid black;
	font-weight:bold;
	background-color: #DCDCDC;
}
td {
  border: 1px solid black;
}
</style>
<table class="first" border="0" cellpadding="2" width="88%" >
<thead>

 <tr >
  <th align="center" style="width:12%">Date/ Time</th>
  <th align="center" style="width:5%"></th>
  <th align="center" style="width:5%">SV</th>
  <th align="center" style="width:5%">CH1</th>
  <th align="center" style="width:5%">CH2</th>
  <th align="center" style="width:5%">CH3</th>
  <th align="center" style="width:5%">CH4</th>
  <th align="center" style="width:5%">CH5</th>
  <th align="center" style="width:5%">CH6</th>
  <th align="center" style="width:5%">CH7</th>
  <th align="center" style="width:5%">CH8</th>
  <th align="center" style="width:5%">CH9</th>
  <th align="center" style="width:5%">CH10</th>
  <th align="center" style="width:5%">CH11</th>
  <th align="center" style="width:5%">CH12</th>
  <th align="center" style="width:5%">CH13</th>
  <th align="center" style="width:5%">CH14</th>
  <th align="center" style="width:5%">CH15</th>
  <th align="center" style="width:5%">CH16</th>
 </tr>
 </thead>
 <tbody>
 $html
 </tbody>
</table>
EOF;

$rem="";

if( $_GET['remark_id']!="")
{
    $rem="";
		 $remark_details=$_GET['remark_id'];
		 
$rem.='
<tr>
<td align="left" colspan="2">'.$remark_details.'</td></tr>
';
$tbl2= <<<EOF
<style>

th{
	border-bottom: 1px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}

table {
	border: 1px solid black;
	border-top: 3px solid black;
}

</style>
<table  cellpadding="3" >
<thead>
 <tr>
  <th>Remark</th>
  <th align="right" style="width:50%;">Username - $get_firstname</th>
 </tr>
</thead>
<tbody>
$rem
</tbody>
</table> 
EOF;
}else
{
   $tbl2= <<<EOF
EOF;
}


$pdf->writeHTML($tbl, true, false, true, false, '');
}

if($temp_channel_num_hum!="")
{
    if($temp_channel_num_hum > 8  )
{
$pdf = new MYPDFS('L', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
}
else{
$pdf = new MYPDF('p', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
}
/*Humidity*/
#################################
######## Humidity ###############
#################################
if($temp_channel_num_hum == '2')
{
    $fromdate= date('d-m-Y H:i:s',strtotime($from_date));
$todate= date('d-m-Y H:i:s',strtotime($to_date));
    $getstat = $this->common_model->get_records('historydb','',array('historydb_seq'=>'1'),'TRUE');
$get_detailstat = $getstat['status'];

if(flagh == 0)
{
$txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}else{
    $txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td>Note: History Database</td></tr>
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}
$pdf->SetHeaderData('', PDF_HEADER_LOGO_WIDTH,$header_title,$txt);
$pdf->SetFont('helvetica', '', 9);
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

$pdf->SetAutoPageBreak(TRUE, 21);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}
$pdf->AddPage();
$pdf->SetFillColor(255, 255, 127);

$pdf->SetFillColor(255, 255, 215);
$tempbands = $this->common_model->get_records('channel_settings',array('temp_alarm_band','humidity_alarm_band'),array('chamber_seq'=>$chamber),'TRUE');		
 $tempalarmband=$tempbands['temp_alarm_band']==null ? "0.0" :$tempbands['temp_alarm_band'];
 $msHumidityBand=$tempbands['humidity_alarm_band']==null ? "0.0" :$tempbands['humidity_alarm_band'];
$tbl1 = <<<EOF
<style>
th{
	border: 0px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}
td {
  border: 0px solid black;
}
</style>
<table class="first" border="0" cellpadding="1" cellspacing="1">
<tr width="99%"><td colspan="2"><b>Temperature in  <sup>o</sup>C, Relative Humidity in %RH, SV: Set Value, Min: Minimum, Max: Maximum, Avg: Average, CH:Channel</b></td></tr>
<tr><td colspan="2"><b>Note : "*" indicates values out of acceptance limit.</b></td></tr>
<tr><td width="40%"><b>Temperature Acceptance Limit ( <sup>o</sup>C):</b>+/- $tempalarmband </td><td width="60%"><b>Humidity Acceptance Limit ( %RH):</b>+/- $msHumidityBand </td></tr>
</table>                   
EOF;
$pdf->writeHTML($tbl1,true, false, true, false, '');
$pdf->SetFillColor(255, 255, 215);
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
$to_date=date('Y-m-d H:i:s',strtotime($to_date));

$header_data=$this->temprature->get_header($chamber,$from_date,$to_date,$temp_channel_num_hum);

$i=1;
foreach ($header_data as $value) {
	$channel=$value['CHANNEL'];
	$mintemp=number_format((float)($value['TMINIMUM']), 1, '.', '');//round($value['TMINIMUM'],1);
	$maxtemp=number_format((float)($value['TMAXIMUM']), 1, '.', '');//round($value['TMAXIMUM'],1);
	$avgtemp=number_format((float)($value['TAVERAGE']), 1, '.', '');//round($value['TAVERAGE'],1);
	$minhum=number_format((float)($value['HMINIMUM']), 1, '.', '');//round($value['HMINIMUM'],1);
	$maxhum=number_format((float)($value['HMAXIMUM']), 1, '.', '');//round($value['HMAXIMUM'],1);
	$avghum=number_format((float)($value['HAVERAGE']), 1, '.', '');//round($value['HAVERAGE'],1);
$txt1 = <<<EOD
<table cellpadding="1" cellspacing="1"  >
<tr><td colspan="6"><b>$i) For Channel : $channel</b></td></tr>
<tr><td><b>Min Temperature: $mintemp</b></td><td><b>Max Temperature: $maxtemp</b></td><td><b>Avg Temperature: $avgtemp</b></td></tr>
<tr><td><b>Min Humidity: $minhum</b></td><td><b>Max Humidity: $maxhum</b></td><td><b>Avg Humidity: $avghum</b></td></tr>
</table>                   
EOD;
$pdf->writeHTML($txt1);
$pdf->SetFillColor(255, 255, 215);
if($temp_channel_num_hum==$i)
{
	break;
}
$i++;
}
    
    
$html="";

	$this->db->select('Record_Date_Time');
	$this->db->where('scanner_details.Record_Date_Time >=',$from_date);
	$this->db->where('scanner_details.Record_Date_Time <=',$to_date);
	$this->db->where('scanner_details.chamber_seq',$chamber);
	$this->db->where("scanner_details.component_cd BETWEEN 'CH1' AND 'CH2'");
	$this->db->group_by('Record_Date_Time');
	$this->db->order_by('Record_Date_Time','asc');
	$query=$this->db->get('scanner_details');
	
	$data=$query->result_array();
	
	for($i=0;$i<count($data);$i++)
	{

	 $ch1=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH1','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch2=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH2','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $temp_hum= $this->temprature->get_sv($chamber,$data[$i]['Record_Date_Time']);
	 $ch1=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch1['Temperature_Value'],$ch1['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch2=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch2['Temperature_Value'],$ch2['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $html.='<tr nobr="true">
	 <td align="center">'.date('d-m-Y H:i:00',strtotime($data[$i]['Record_Date_Time'])).'</td>
	 <td align="center">Temp <br> Hum</td>
	 <td align="center">'.number_format((float)($temp_hum['Temperature_setpoint']), 1, '.', '').'<br>'.number_format((float)($temp_hum['Humidity_setpoint']), 1, '.', '').'</td>
	 <td align="center">'.$ch1['Temperature_Value'].' <br> '.$ch1['Humidity_Value'].'</td>
	 <td align="center">'.$ch2['Temperature_Value'].' <br> '.$ch2['Humidity_Value'].'</td>
	
	 </tr>';
	}

$tbl = <<<EOF
<style>

th{
	border: 1px solid black;
	font-weight:bold;
	background-color: #DCDCDC;
}
td {
  border: 1px solid black;
}
</style>
<table class="first" border="0" cellpadding="4" width="95%" >
<thead>
 <tr >
  <th align="center">Date/ Time</th>
  <th align="center"></th>
  <th align="center">SV</th>
  <th align="center">CH1</th>
  <th align="center">CH2</th>
 
 </tr>
 </thead>
	<tbody>
	$html
	</tbody>
</table>
EOF;

$rem="";

if( $_GET['remark_id']!="")
{
    $rem="";
		 $remark_details=$_GET['remark_id'];
		 
$rem.='
<tr>
<td align="left" colspan="2">'.$remark_details.'</td></tr>
';
$tbl2= <<<EOF
<style>

th{
	border-bottom: 1px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}

table {
	border: 1px solid black;
	border-top: 3px solid black;
}

</style>
<table  cellpadding="3" >
<thead>
 <tr>
  <th>Remark</th>
  <th align="right" style="width:50%;">Username - $get_firstname</th>
 </tr>
</thead>
<tbody>
$rem
</tbody>
</table> 
EOF;
}else
{
   $tbl2= <<<EOF
EOF;
}

$pdf->writeHTML($tbl, true, false, true, false, '');
}


if($temp_channel_num_hum == '4')
{
    $fromdate= date('d-m-Y H:i:s',strtotime($from_date));
$todate= date('d-m-Y H:i:s',strtotime($to_date));
    $getstat = $this->common_model->get_records('historydb','',array('historydb_seq'=>'1'),'TRUE');
$get_detailstat = $getstat['status'];

if(flagh == 0)
{
$txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}else{
    $txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td>Note: History Database</td></tr>
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}
$pdf->SetHeaderData('', PDF_HEADER_LOGO_WIDTH,$header_title,$txt);
$pdf->SetFont('helvetica', '', 9);
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

$pdf->SetAutoPageBreak(TRUE, 21);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}
$pdf->AddPage();
$pdf->SetFillColor(255, 255, 127);

$pdf->SetFillColor(255, 255, 215);
$tempbands = $this->common_model->get_records('channel_settings',array('temp_alarm_band','humidity_alarm_band'),array('chamber_seq'=>$chamber),'TRUE');		
 $tempalarmband=$tempbands['temp_alarm_band']==null ? "0.0" :$tempbands['temp_alarm_band'];
 $msHumidityBand=$tempbands['humidity_alarm_band']==null ? "0.0" :$tempbands['humidity_alarm_band'];
$tbl1 = <<<EOF
<style>
th{
	border: 0px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}
td {
  border: 0px solid black;
}
</style>
<table class="first" border="0" cellpadding="1" cellspacing="1">
<tr width="99%"><td colspan="2"><b>Temperature in  <sup>o</sup>C, Relative Humidity in %RH, SV: Set Value, Min: Minimum, Max: Maximum, Avg: Average, CH:Channel</b></td></tr>
<tr><td colspan="2"><b>Note : "*" indicates values out of acceptance limit.</b></td></tr>
<tr><td width="40%"><b>Temperature Acceptance Limit ( <sup>o</sup>C):</b>+/- $tempalarmband </td><td width="60%"><b>Humidity Acceptance Limit ( %RH):</b>+/- $msHumidityBand </td></tr>
</table>                   
EOF;
$pdf->writeHTML($tbl1,true, false, true, false, '');
$pdf->SetFillColor(255, 255, 215);
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
$to_date=date('Y-m-d H:i:s',strtotime($to_date));

$header_data=$this->temprature->get_header($chamber,$from_date,$to_date,$temp_channel_num_hum);

$i=1;
foreach ($header_data as $value) {
	$channel=$value['CHANNEL'];
	
	$mintemp=number_format((float)($value['TMINIMUM']), 1, '.', '');//round($value['TMINIMUM'],1);
	$maxtemp=number_format((float)($value['TMAXIMUM']), 1, '.', '');//round($value['TMAXIMUM'],1);
	$avgtemp=number_format((float)($value['TAVERAGE']), 1, '.', '');//round($value['TAVERAGE'],1);
	$minhum=number_format((float)($value['HMINIMUM']), 1, '.', '');//round($value['HMINIMUM'],1);
	$maxhum=number_format((float)($value['HMAXIMUM']), 1, '.', '');//round($value['HMAXIMUM'],1);
	$avghum=number_format((float)($value['HAVERAGE']), 1, '.', '');//round($value['HAVERAGE'],1);
	
	
$txt1 = <<<EOD
<table cellpadding="1" cellspacing="1"  >
<tr><td colspan="6"><b>$i) For Channel : $channel</b></td></tr>
<tr><td><b>Min Temperature: $mintemp</b></td><td><b>Max Temperature: $maxtemp</b></td><td><b>Avg Temperature: $avgtemp</b></td></tr>
<tr><td><b>Min Humidity: $minhum</b></td><td><b>Max Humidity: $maxhum</b></td><td><b>Avg Humidity: $avghum</b></td></tr>

</table>                   
EOD;
$pdf->writeHTML($txt1);
$pdf->SetFillColor(255, 255, 215);
if($temp_channel_num_hum==$i)
{
	break;
}
$i++;
}
    
    
$html="";

	$this->db->select('Record_Date_Time');
	$this->db->where('scanner_details.Record_Date_Time >=',$from_date);
	$this->db->where('scanner_details.Record_Date_Time <=',$to_date);
	$this->db->where('scanner_details.chamber_seq',$chamber);
	$this->db->where("scanner_details.component_cd BETWEEN 'CH1' AND 'CH4'");
	$this->db->group_by('Record_Date_Time');
	$query=$this->db->get('scanner_details');
//	echo $this->db->last_query();exit;
	$data=$query->result_array();

	for($i=0;$i<count($data);$i++)
	{

	 $ch1=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH1','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch2=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH2','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch3=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH3','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch4=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH4','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $temp_hum= $this->temprature->get_sv($chamber,$data[$i]['Record_Date_Time']);
	 $ch1=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch1['Temperature_Value'],$ch1['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch2=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch2['Temperature_Value'],$ch2['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch3=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch3['Temperature_Value'],$ch3['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch4=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch4['Temperature_Value'],$ch4['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $html.='<tr nobr="true">
	 <td align="center">'.date('d-m-Y H:i:00',strtotime($data[$i]['Record_Date_Time'])).'</td>
	 <td align="center">Temp <br> Hum</td>
	 <td align="center">'.number_format((float)($temp_hum['Temperature_setpoint']), 1, '.', '').'<br>'.number_format((float)($temp_hum['Humidity_setpoint']), 1, '.', '').'</td>
	 <td align="center">'.$ch1['Temperature_Value'].' <br> '.$ch1['Humidity_Value'].'</td>
	 <td align="center">'.$ch2['Temperature_Value'].' <br> '.$ch2['Humidity_Value'].'</td>
	 <td align="center">'.$ch3['Temperature_Value'].' <br> '.$ch3['Humidity_Value'].'</td>
	 <td align="center">'.$ch4['Temperature_Value'].' <br> '.$ch4['Humidity_Value'].'</td>
	 
	 </tr>';
	}

$tbl = <<<EOF
<style>

th{
	border: 1px solid black;
	font-weight:bold;
	background-color: #DCDCDC;
}
td {
  border: 1px solid black;
}
</style>
<table class="first" border="0" cellpadding="4" width="95%" >
<thead>
 <tr >
  <th align="center">Date/ Time</th>
  <th align="center"></th>
  <th align="center">SV</th>
  <th align="center">CH1</th>
  <th align="center">CH2</th>
  <th align="center">CH3</th>
  <th align="center">CH4</th>
 </tr>
 </thead>
	<tbody>
	$html
	</tbody>
</table>
EOF;

$rem="";

if( $_GET['remark_id']!="")
{
    $rem="";
		 $remark_details=$_GET['remark_id'];
		 
$rem.='
<tr>
<td align="left" colspan="2">'.$remark_details.'</td></tr>
';
$tbl2= <<<EOF
<style>

th{
	border-bottom: 1px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}

table {
	border: 1px solid black;
	border-top: 3px solid black;
}

</style>
<table  cellpadding="3" >
<thead>
 <tr>
  <th>Remark</th>
  <th align="right" style="width:50%;">Username - $get_firstname</th>
 </tr>
</thead>
<tbody>
$rem
</tbody>
</table> 
EOF;
}else
{
   $tbl2= <<<EOF
EOF;
}

$pdf->writeHTML($tbl, true, false, true, false, '');
}

if($temp_channel_num_hum == '8')
{
   $fromdate= date('d-m-Y H:i:s',strtotime($from_date));
$todate= date('d-m-Y H:i:s',strtotime($to_date));    
    
      $getstat = $this->common_model->get_records('historydb','',array('historydb_seq'=>'1'),'TRUE');
$get_detailstat = $getstat['status'];

if(flagh == 0)
{
$txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}else{
    $txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td>Note: History Database</td></tr>
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}
$pdf->SetHeaderData('', PDF_HEADER_LOGO_WIDTH,$header_title,$txt);
$pdf->SetFont('helvetica', '', 9);
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

$pdf->SetAutoPageBreak(TRUE, 21);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}
$pdf->AddPage();
$pdf->SetFillColor(255, 255, 127);

$pdf->SetFillColor(255, 255, 215);
$tempbands = $this->common_model->get_records('channel_settings',array('temp_alarm_band','humidity_alarm_band'),array('chamber_seq'=>$chamber),'TRUE');		
 $tempalarmband=$tempbands['temp_alarm_band']==null ? "0.0" :$tempbands['temp_alarm_band'];
 $msHumidityBand=$tempbands['humidity_alarm_band']==null ? "0.0" :$tempbands['humidity_alarm_band'];
$tbl1 = <<<EOF
<style>
th{
	border: 0px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}
td {
  border: 0px solid black;
}
</style>
<table class="first" border="0" cellpadding="1" cellspacing="1">
<tr width="99%"><td colspan="2"><b>Temperature in  <sup>o</sup>C, Relative Humidity in %RH, SV: Set Value, Min: Minimum, Max: Maximum, Avg: Average, CH:Channel</b></td></tr>
<tr><td colspan="2"><b>Note : "*" indicates values out of acceptance limit.</b></td></tr>
<tr><td width="40%"><b>Temperature Acceptance Limit ( <sup>o</sup>C):</b>+/- $tempalarmband </td><td width="60%"><b>Humidity Acceptance Limit ( %RH):</b>+/- $msHumidityBand </td></tr>
</table>                   
EOF;
$pdf->writeHTML($tbl1,true, false, true, false, '');
$pdf->SetFillColor(255, 255, 215);
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
$to_date=date('Y-m-d H:i:s',strtotime($to_date));

$header_data=$this->temprature->get_header($chamber,$from_date,$to_date,$temp_channel_num_hum);

$i=1;
foreach ($header_data as $value) {
	$channel=$value['CHANNEL'];
	
	$mintemp=number_format((float)($value['TMINIMUM']), 1, '.', '');//round($value['TMINIMUM'],1);
	$maxtemp=number_format((float)($value['TMAXIMUM']), 1, '.', '');//round($value['TMAXIMUM'],1);
	$avgtemp=number_format((float)($value['TAVERAGE']), 1, '.', '');//round($value['TAVERAGE'],1);
	$minhum=number_format((float)($value['HMINIMUM']), 1, '.', '');//round($value['HMINIMUM'],1);
	$maxhum=number_format((float)($value['HMAXIMUM']), 1, '.', '');//round($value['HMAXIMUM'],1);
	$avghum=number_format((float)($value['HAVERAGE']), 1, '.', '');//round($value['HAVERAGE'],1);
	
	
$txt1 = <<<EOD
<table cellpadding="1" cellspacing="1"  >
<tr><td colspan="6"><b>$i) For Channel : $channel</b></td></tr>
<tr><td><b>Min Temperature: $mintemp</b></td><td><b>Max Temperature: $maxtemp</b></td><td><b>Avg Temperature: $avgtemp</b></td></tr>
<tr><td><b>Min Humidity: $minhum</b></td><td><b>Max Humidity: $maxhum</b></td><td><b>Avg Humidity: $avghum</b></td></tr>
</table>                   
EOD;
$pdf->writeHTML($txt1);
$pdf->SetFillColor(255, 255, 215);
if($temp_channel_num_hum==$i)
{
	break;
}
$i++;
}

    $html="";
// Table with rowspans and THEAD
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
 $to_date=date('Y-m-d H:i:s',strtotime( $to_date));
	$this->db->select('Record_Date_Time');
	$this->db->where('scanner_details.Record_Date_Time >=',$from_date);
	$this->db->where('scanner_details.Record_Date_Time <=',$to_date);
	$this->db->where('scanner_details.chamber_seq',$chamber);
	$this->db->where("scanner_details.component_cd BETWEEN 'CH1' AND 'CH8'");
	$this->db->group_by('Record_Date_Time');
	$query=$this->db->get('scanner_details');
	$data=$query->result_array();


for($i=0;$i<count($data);$i++)
{
	 $ch1=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH1','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch2=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH2','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch3=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH3','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch4=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH4','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch5=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH5','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch6=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH6','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch7=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH7','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch8=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH8','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $temp_hum= $this->temprature->get_sv($chamber,$data[$i]['Record_Date_Time']);
	 $ch1=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch1['Temperature_Value'],$ch1['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch2=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch2['Temperature_Value'],$ch2['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch3=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch3['Temperature_Value'],$ch3['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch4=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch4['Temperature_Value'],$ch4['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch5=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch5['Temperature_Value'],$ch5['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch6=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch6['Temperature_Value'],$ch6['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch7=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch7['Temperature_Value'],$ch7['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch8=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch8['Temperature_Value'],$ch8['Humidity_Value'],$tempalarmband,$msHumidityBand);
 $html.='<tr nobr="true">
 <td align="center" style="width:25%">'.date('d-m-Y H:i:00',strtotime($data[$i]['Record_Date_Time'])).'</td>
 <td align="center" style="width:7%">Temp <br> Hum</td>
 
 <td align="center" style="width:7%">'.number_format((float)($temp_hum['Temperature_setpoint']), 1, '.', '').'<br>'.number_format((float)($temp_hum['Humidity_setpoint']), 1, '.', '').'</td>
	 <td align="center" style="width:7%">'.$ch1['Temperature_Value'].' <br> '.$ch1['Humidity_Value'].'</td>
	 <td align="center" style="width:7%">'.$ch2['Temperature_Value'].' <br> '.$ch2['Humidity_Value'].'</td>
	 <td align="center" style="width:7%">'.$ch3['Temperature_Value'].' <br> '.$ch3['Humidity_Value'].'</td>
	 <td align="center" style="width:7%">'.$ch4['Temperature_Value'].' <br> '.$ch4['Humidity_Value'].'</td>
	 <td align="center" style="width:7%">'.$ch5['Temperature_Value'].' <br> '.$ch5['Humidity_Value'].'</td>
	 <td align="center" style="width:7%">'.$ch6['Temperature_Value'].' <br> '.$ch6['Humidity_Value'].'</td>
	 <td align="center" style="width:7%">'.$ch7['Temperature_Value'].' <br> '.$ch7['Humidity_Value'].'</td>
	 <td align="center" style="width:7%">'.$ch8['Temperature_Value'].' <br> '.$ch8['Humidity_Value'].'</td>
	 
 </tr>';
}

$tbl = <<<EOF
<style>

th{
	border: 1px solid black;
	font-weight:bold;
	background-color: #DCDCDC;
}
td {
  border: 1px solid black;
}
</style>
<table class="first" border="0" cellpadding="4" max-width="100%" >
<thead>

 <tr >
  <th align="center" style="width:25%">Date/ Time</th>
  <th align="center" style="width:7%"></th>
  <th align="center" style="width:7%">SV</th>
  <th align="center" style="width:7%">CH1</th>
  <th align="center" style="width:7%">CH2</th>
  <th align="center" style="width:7%">CH3</th>
  <th align="center" style="width:7%">CH4</th>
  <th align="center" style="width:7%">CH5</th>
  <th align="center" style="width:7%">CH6</th>
  <th align="center" style="width:7%">CH7</th>
 <th align="center" style="width:7%">CH8</th>
 </tr>
 </thead>
 <tbody>
 $html
 </tbody>
</table>
EOF;

$rem="";

if( $_GET['remark_id']!="")
{
    $rem="";
		 $remark_details=$_GET['remark_id'];
		 
$rem.='
<tr>
<td align="left" colspan="2">'.$remark_details.'</td></tr>
';
$tbl2= <<<EOF
<style>

th{
	border-bottom: 1px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}

table {
	border: 1px solid black;
	border-top: 3px solid black;
}

</style>
<table cellpadding="3" >
<thead>
 <tr>
  <th>Remark</th>
  <th align="right" style="width:50%;">Username - $get_firstname</th>
 </tr>
</thead>
<tbody>
$rem
</tbody>
</table> 
EOF;
}else
{
   $tbl2= <<<EOF

EOF;
}
$pdf->writeHTML($tbl, true, false, true, false, '');
}

if($temp_channel_num_hum == '9')
{
    $fromdate= date('d-m-Y H:i:s',strtotime($from_date));
$todate= date('d-m-Y H:i:s',strtotime($to_date));
       $getstat = $this->common_model->get_records('historydb','',array('historydb_seq'=>'1'),'TRUE');
$get_detailstat = $getstat['status'];

if(flagh == 0)
{
$txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}else{
    $txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td>Note: History Database</td></tr>
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}
$pdf->SetHeaderData('', PDF_HEADER_LOGO_WIDTH,$header_title,$txt);
$pdf->SetFont('helvetica', '', 9);
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

$pdf->SetAutoPageBreak(TRUE, 21);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}
$pdf->AddPage();
$pdf->SetFillColor(255, 255, 127);

$pdf->SetFillColor(255, 255, 215);
$tempbands = $this->common_model->get_records('channel_settings',array('temp_alarm_band','humidity_alarm_band'),array('chamber_seq'=>$chamber),'TRUE');		
 $tempalarmband=$tempbands['temp_alarm_band']==null ? "0.0" :$tempbands['temp_alarm_band'];
 $msHumidityBand=$tempbands['humidity_alarm_band']==null ? "0.0" :$tempbands['humidity_alarm_band'];
$tbl1 = <<<EOF
<style>
th{
	border: 0px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}
td {
  border: 0px solid black;
}
</style>
<table class="first" border="0" cellpadding="1" cellspacing="1">
<tr width="99%"><td colspan="2"><b>Temperature in  <sup>o</sup>C, Relative Humidity in %RH, SV: Set Value, Min: Minimum, Max: Maximum, Avg: Average, CH:Channel</b></td></tr>
<tr><td colspan="2"><b>Note : "*" indicates values out of acceptance limit.</b></td></tr>
<tr><td width="40%"><b>Temperature Acceptance Limit ( <sup>o</sup>C):</b>+/- $tempalarmband </td><td width="60%"><b>Humidity Acceptance Limit ( %RH):</b>+/- $msHumidityBand </td></tr>
</table>                   
EOF;
$pdf->writeHTML($tbl1,true, false, true, false, '');
$pdf->SetFillColor(255, 255, 215);
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
$to_date=date('Y-m-d H:i:s',strtotime($to_date));

$header_data=$this->temprature->get_header($chamber,$from_date,$to_date,$temp_channel_num_hum);

$i=1;
foreach ($header_data as $value) {
	$channel=$value['CHANNEL'];
	$mintemp=number_format((float)($value['TMINIMUM']), 1, '.', '');//round($value['TMINIMUM'],1);
	$maxtemp=number_format((float)($value['TMAXIMUM']), 1, '.', '');//round($value['TMAXIMUM'],1);
	$avgtemp=number_format((float)($value['TAVERAGE']), 1, '.', '');//round($value['TAVERAGE'],1);
	$minhum=number_format((float)($value['HMINIMUM']), 1, '.', '');//round($value['HMINIMUM'],1);
	$maxhum=number_format((float)($value['HMAXIMUM']), 1, '.', '');//round($value['HMAXIMUM'],1);
	$avghum=number_format((float)($value['HAVERAGE']), 1, '.', '');//round($value['HAVERAGE'],1);
	
$txt1 = <<<EOD
<table cellpadding="1" cellspacing="1"  >
<tr><td colspan="6"><b>$i) For Channel : $channel</b></td></tr>
<tr><td><b>Min Temperature: $mintemp</b></td><td><b>Max Temperature: $maxtemp</b></td><td><b>Avg Temperature: $avgtemp</b></td></tr>
<tr><td><b>Min Humidity: $minhum</b></td><td><b>Max Humidity: $maxhum</b></td><td><b>Avg Humidity: $avghum</b></td></tr>
</table>                   
EOD;
$pdf->writeHTML($txt1);
$pdf->SetFillColor(255, 255, 215);
if($temp_channel_num_hum==$i)
{
	break;
}
$i++;
}

    $html="";
// Table with rowspans and THEAD
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
 $to_date=date('Y-m-d H:i:s',strtotime( $to_date));
	$this->db->select('Record_Date_Time');
	$this->db->where('scanner_details.Record_Date_Time >=',$from_date);
	$this->db->where('scanner_details.Record_Date_Time <=',$to_date);
	$this->db->where('scanner_details.chamber_seq',$chamber);
	$this->db->where("scanner_details.component_cd BETWEEN 'CH1' AND 'CH9'");
	$this->db->group_by('Record_Date_Time');
	$query=$this->db->get('scanner_details');
	$data=$query->result_array();


for($i=0;$i<count($data);$i++)
{
	 $ch1=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH1','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch2=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH2','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch3=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH3','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch4=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH4','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch5=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH5','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch6=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH6','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch7=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH7','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch8=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH8','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch9=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH9','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $temp_hum= $this->temprature->get_sv($chamber,$data[$i]['Record_Date_Time']);
	 $ch1=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch1['Temperature_Value'],$ch1['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch2=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch2['Temperature_Value'],$ch2['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch3=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch3['Temperature_Value'],$ch3['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch4=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch4['Temperature_Value'],$ch4['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch5=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch5['Temperature_Value'],$ch5['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch6=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch6['Temperature_Value'],$ch6['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch7=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch7['Temperature_Value'],$ch7['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch8=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch8['Temperature_Value'],$ch8['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch9=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch9['Temperature_Value'],$ch9['Humidity_Value'],$tempalarmband,$msHumidityBand);
 $html.='<tr nobr="true" >
 <td align="center" style="width:25%">'.date('d-m-Y H:i:00',strtotime($data[$i]['Record_Date_Time'])).'</td>
 <td align="center" style="width:7%">Temp <br> Hum</td>
 	 <td align="center" style="width:7%">'.number_format((float)($temp_hum['Temperature_setpoint']), 1, '.', '').'<br>'.number_format((float)($temp_hum['Humidity_setpoint']), 1, '.', '').'</td>
	 <td align="center" style="width:7%">'.$ch1['Temperature_Value'].' <br> '.$ch1['Humidity_Value'].'</td>
	 <td align="center" style="width:7%">'.$ch2['Temperature_Value'].' <br> '.$ch2['Humidity_Value'].'</td>
	 <td align="center" style="width:7%">'.$ch3['Temperature_Value'].' <br> '.$ch3['Humidity_Value'].'</td>
	 <td align="center" style="width:7%">'.$ch4['Temperature_Value'].' <br> '.$ch4['Humidity_Value'].'</td>
	 <td align="center" style="width:7%">'.$ch5['Temperature_Value'].' <br> '.$ch5['Humidity_Value'].'</td>
	 <td align="center" style="width:7%">'.$ch6['Temperature_Value'].' <br> '.$ch6['Humidity_Value'].'</td>
	 <td align="center" style="width:7%">'.$ch7['Temperature_Value'].' <br> '.$ch7['Humidity_Value'].'</td>
	 <td align="center" style="width:7%">'.$ch8['Temperature_Value'].' <br> '.$ch8['Humidity_Value'].'</td>
	 <td align="center" style="width:7%">'.$ch9['Temperature_Value'].' <br> '.$ch9['Humidity_Value'].'</td>
 </tr>';
}

$tbl = <<<EOF
<style>

th{
	border: 1px solid black;
	font-weight:bold;
	background-color: #DCDCDC;
}
td {
  border: 1px solid black;
}
</style>
<table class="first" border="0" cellpadding="4" max-width="100%" >
<thead>

 <tr >
  <th align="center" style="width:25%">Date/ Time</th>
  <th align="center" style="width:7%"></th>
  <th align="center" style="width:7%">SV</th>
  <th align="center" style="width:7%">CH1</th>
  <th align="center" style="width:7%">CH2</th>
  <th align="center" style="width:7%">CH3</th>
  <th align="center" style="width:7%">CH4</th>
  <th align="center" style="width:7%">CH5</th>
  <th align="center" style="width:7%">CH6</th>
  <th align="center" style="width:7%">CH7</th>
 <th align="center" style="width:7%">CH8</th>
  <th align="center" style="width:7%">CH9</th>
 </tr>
 </thead>
 <tbody>
 $html
 </tbody>
</table>
EOF;

$rem="";

if( $_GET['remark_id']!="")
{
   $rem="";
		 $remark_details=$_GET['remark_id'];
		 
$rem.='
<tr>
<td align="left" colspan="2">'.$remark_details.'</td></tr>
';
$tbl2= <<<EOF
<style>

th{
	border-bottom: 1px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}

table {
	border: 1px solid black;
	border-top: 3px solid black;
}

</style>
<table  cellpadding="3" >
<thead>
 <tr>
  <th>Remark</th>
  <th align="right" style="width:50%;">Username - $get_firstname</th>
 </tr>
</thead>
<tbody>
$rem
</tbody>
</table> 
EOF;
}else
{
   $tbl2= <<<EOF

EOF;
}
$pdf->writeHTML($tbl, true, false, true, false, '');
}

if($temp_channel_num_hum == '12')
{
    $fromdate= date('d-m-Y H:i:s',strtotime($from_date));
$todate= date('d-m-Y H:i:s',strtotime($to_date));
      $getstat = $this->common_model->get_records('historydb','',array('historydb_seq'=>'1'),'TRUE');
$get_detailstat = $getstat['status'];

if(flagh == 0)
{
$txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}else{
    $txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td>Note: History Database</td></tr>
<tr><td colspan="2"><b>Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}
$pdf->SetHeaderData('', PDF_HEADER_LOGO_WIDTH,$header_title,$txt);
$pdf->SetFont('helvetica', 'B', 9);
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

$pdf->SetAutoPageBreak(TRUE, 21);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}
$pdf->AddPage();
$pdf->SetFillColor(255, 255, 127);

$pdf->SetFillColor(255, 255, 215);
$tempbands = $this->common_model->get_records('channel_settings',array('temp_alarm_band','humidity_alarm_band'),array('chamber_seq'=>$chamber),'TRUE');		
 $tempalarmband=$tempbands['temp_alarm_band']==null ? "0.0" :$tempbands['temp_alarm_band'];
 $msHumidityBand=$tempbands['humidity_alarm_band']==null ? "0.0" :$tempbands['humidity_alarm_band'];
$tbl1 = <<<EOF
<style>
th{
	border: 0px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}
td {
  border: 0px solid black;
}
</style>
<table class="first" border="0" cellpadding="1" cellspacing="1">
<tr width="99%"><td colspan="2"><b>Temperature in  <sup>o</sup>C, Relative Humidity in %RH, SV: Set Value, Min: Minimum, Max: Maximum, Avg: Average, CH:Channel</b></td></tr>>
<tr><td colspan="2"><b>Note : "*" indicates values out of acceptance limit.</b></td></tr>
<tr><td width="40%"><b>Temperature Acceptance Limit ( <sup>o</sup>C):</b>+/- $tempalarmband </td><td width="60%"><b>Humidity Acceptance Limit ( %RH):</b>+/- $msHumidityBand </td></tr>
</table>                   
EOF;
$pdf->writeHTML($tbl1,true, false, true, false, '');
$pdf->SetFillColor(255, 255, 215);
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
$to_date=date('Y-m-d H:i:s',strtotime($to_date));

$header_data=$this->temprature->get_header($chamber,$from_date,$to_date,$temp_channel_num_hum);

$i=1;
foreach ($header_data as $value) {
	$channel=$value['CHANNEL'];
	$mintemp=number_format((float)($value['TMINIMUM']), 1, '.', '');//round($value['TMINIMUM'],1);
	$maxtemp=number_format((float)($value['TMAXIMUM']), 1, '.', '');//round($value['TMAXIMUM'],1);
	$avgtemp=number_format((float)($value['TAVERAGE']), 1, '.', '');//round($value['TAVERAGE'],1);
	$minhum=number_format((float)($value['HMINIMUM']), 1, '.', '');//round($value['HMINIMUM'],1);
	$maxhum=number_format((float)($value['HMAXIMUM']), 1, '.', '');//round($value['HMAXIMUM'],1);
	$avghum=number_format((float)($value['HAVERAGE']), 1, '.', '');//round($value['HAVERAGE'],1);
	
$txt1 = <<<EOD
<table cellpadding="1" cellspacing="1"  >
<tr><td colspan="6"><b>$i) For Channel : $channel</b></td></tr>
<tr><td><b>Min Temperature: $mintemp</b></td><td><b>Max Temperature: $maxtemp</b></td><td><b>Avg Temperature: $avgtemp</b></td></tr>
<tr><td><b>Min Humidity: $minhum</b></td><td><b>Max Humidity: $maxhum</b></td><td><b>Avg Humidity: $avghum</b></td></tr>
</table>                   
EOD;
$pdf->writeHTML($txt1);
$pdf->SetFillColor(255, 255, 215);
if($temp_channel_num_hum==$i)
{
	break;
}
$i++;
}

    $html="";
// Table with rowspans and THEAD
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
 $to_date=date('Y-m-d H:i:s',strtotime( $to_date));
	$this->db->select('Record_Date_Time');
	$this->db->where('scanner_details.Record_Date_Time >=',$from_date);
	$this->db->where('scanner_details.Record_Date_Time <=',$to_date);
	$this->db->where('scanner_details.chamber_seq',$chamber);
	$this->db->where("scanner_details.component_cd BETWEEN 'CH1' AND 'CH12'");
	$this->db->group_by('Record_Date_Time');
	$query=$this->db->get('scanner_details');
	$data=$query->result_array();


for($i=0;$i<count($data);$i++)
{
	 $ch1=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH1','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch2=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH2','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch3=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH3','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch4=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH4','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch5=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH5','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch6=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH6','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch7=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH7','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch8=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH8','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch9=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH9','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch10=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH10','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch11=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH11','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch12=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH12','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $temp_hum= $this->temprature->get_sv($chamber,$data[$i]['Record_Date_Time']);
	 $ch1=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch1['Temperature_Value'],$ch1['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch2=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch2['Temperature_Value'],$ch2['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch3=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch3['Temperature_Value'],$ch3['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch4=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch4['Temperature_Value'],$ch4['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch5=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch5['Temperature_Value'],$ch5['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch6=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch6['Temperature_Value'],$ch6['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch7=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch7['Temperature_Value'],$ch7['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch8=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch8['Temperature_Value'],$ch8['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch9=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch9['Temperature_Value'],$ch9['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch10=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch10['Temperature_Value'],$ch10['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch11=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch11['Temperature_Value'],$ch11['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch12=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch12['Temperature_Value'],$ch12['Humidity_Value'],$tempalarmband,$msHumidityBand);
 $html.='<tr nobr="true">
 <td align="center" style="width:20%">'.date('d-m-Y H:i:00',strtotime($data[$i]['Record_Date_Time'])).'</td>
 <td align="center" style="width:5%">Temp <br> Hum</td>
 	 <td align="center" style="width:5%">'.number_format((float)($temp_hum['Temperature_setpoint']), 1, '.', '').'<br>'.number_format((float)($temp_hum['Humidity_setpoint']), 1, '.', '').'</td>
	 <td align="center" style="width:5%">'.$ch1['Temperature_Value'].' <br> '.$ch1['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch2['Temperature_Value'].' <br> '.$ch2['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch3['Temperature_Value'].' <br> '.$ch3['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch4['Temperature_Value'].' <br> '.$ch4['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch5['Temperature_Value'].' <br> '.$ch5['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch6['Temperature_Value'].' <br> '.$ch6['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch7['Temperature_Value'].' <br> '.$ch7['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch8['Temperature_Value'].' <br> '.$ch8['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch9['Temperature_Value'].' <br> '.$ch9['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch10['Temperature_Value'].' <br> '.$ch10['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch11['Temperature_Value'].' <br> '.$ch11['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch12['Temperature_Value'].' <br> '.$ch12['Humidity_Value'].'</td>
	 
	 
	 
 </tr>';
}

$tbl = <<<EOF
<style>

th{
	border: 1px solid black;
	font-weight:bold;
	background-color: #DCDCDC;
}
td {
  border: 1px solid black;
}
</style>
<table class="first" border="0" cellpadding="4" max-width="100%" >
<thead>

 <tr >
  <th align="center" style="width:20%">Date/ Time</th>
  <th align="center" style="width:5%"></th>
  <th align="center" style="width:5%">SV</th>
  <th align="center" style="width:5%">CH1</th>
  <th align="center" style="width:5%">CH2</th>
  <th align="center" style="width:5%">CH3</th>
  <th align="center" style="width:5%">CH4</th>
  <th align="center" style="width:5%">CH5</th>
  <th align="center" style="width:5%">CH6</th>
  <th align="center" style="width:5%">CH7</th>
  <th align="center" style="width:5%">CH8</th>
  <th align="center" style="width:5%">CH9</th>
  <th align="center" style="width:5%">CH10</th>
  <th align="center" style="width:5%">CH11</th>
  <th align="center" style="width:5%">CH12</th>
 </tr>
 </thead>
 <tbody>
 $html
 </tbody>
</table>
EOF;

$rem="";

if( $_GET['remark_id']!="")
{
    $rem="";
		 $remark_details=$_GET['remark_id'];
		 
$rem.='
<tr>
<td align="left" colspan="2">'.$remark_details.'</td></tr>
';
$tbl2= <<<EOF
<style>

th{
	border-bottom: 1px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}

table {
	border: 1px solid black;
	border-top: 3px solid black;
}

</style>
<table  cellpadding="3" >
<thead>
 <tr>
  <th>Remark</th>
  <th align="right" style="width:50%;">Username - $get_firstname</th>
 </tr>
</thead>
<tbody>
$rem
</tbody>
</table> 
EOF;
}else
{
   $tbl2= <<<EOF

EOF;
}
$pdf->writeHTML($tbl, true, false, true, false, '');
}
if($temp_channel_num_hum == '14')
{
    
$fromdate= date('d-m-Y H:i:s',strtotime($from_date));
$todate= date('d-m-Y H:i:s',strtotime($to_date));

  $getstat = $this->common_model->get_records('historydb','',array('historydb_seq'=>'1'),'TRUE');
$get_detailstat = $getstat['status'];

if(flagh == 0)
{
$txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td colspan="2"><b> Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}else{
    $txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td>Note: History Database</td></tr>
<tr><td colspan="2"><b> Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}
$pdf->SetHeaderData('', PDF_HEADER_LOGO_WIDTH,$header_title,$txt);
$pdf->SetFont('helvetica', '', 9);
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

$pdf->SetAutoPageBreak(TRUE, 21);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}
$pdf->AddPage();
$pdf->SetFillColor(255, 255, 127);

$pdf->SetFillColor(255, 255, 215);
$tempbands = $this->common_model->get_records('channel_settings',array('temp_alarm_band','humidity_alarm_band'),array('chamber_seq'=>$chamber),'TRUE');		
 $tempalarmband=$tempbands['temp_alarm_band']==null ? "0.0" :$tempbands['temp_alarm_band'];
 $msHumidityBand=$tempbands['humidity_alarm_band']==null ? "0.0" :$tempbands['humidity_alarm_band'];
$tbl1 = <<<EOF
<style>
th{
	border: 0px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}
td {
  border: 0px solid black;
}
</style>
<table class="first" border="0" cellpadding="1" cellspacing="1">
<tr width="99%"><td colspan="2"><b>Temperature in  <sup>o</sup>C, Relative Humidity in %RH, SV: Set Value, Min: Minimum, Max: Maximum, Avg: Average, CH:Channel</b></td></tr>
<tr><td colspan="2"><b>Note : "*" indicates values out of acceptance limit.</b></td></tr>
<tr><td width="40%"><b>Temperature Acceptance Limit ( <sup>o</sup>C):</b>+/- $tempalarmband </td><td width="60%"><b>Humidity Acceptance Limit ( %RH):</b>+/- $msHumidityBand </td></tr>
</table>                   
EOF;
$pdf->writeHTML($tbl1,true, false, true, false, '');
$pdf->SetFillColor(255, 255, 215);
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
$to_date=date('Y-m-d H:i:s',strtotime($to_date));

$header_data=$this->temprature->get_header($chamber,$from_date,$to_date,$temp_channel_num_hum);

$i=1;
foreach ($header_data as $value) {
	$channel=$value['CHANNEL'];
	$mintemp=number_format((float)($value['TMINIMUM']), 1, '.', '');//round($value['TMINIMUM'],1);
	$maxtemp=number_format((float)($value['TMAXIMUM']), 1, '.', '');//round($value['TMAXIMUM'],1);
	$avgtemp=number_format((float)($value['TAVERAGE']), 1, '.', '');//round($value['TAVERAGE'],1);
	$minhum=number_format((float)($value['HMINIMUM']), 1, '.', '');//round($value['HMINIMUM'],1);
	$maxhum=number_format((float)($value['HMAXIMUM']), 1, '.', '');//round($value['HMAXIMUM'],1);
	$avghum=number_format((float)($value['HAVERAGE']), 1, '.', '');//round($value['HAVERAGE'],1);
	
$txt1 = <<<EOD
<table cellpadding="1" cellspacing="1"  >
<tr><td colspan="6"><b>$i) For Channel : $channel</b></td></tr>
<tr><td><b>Min Temperature: $mintemp</b></td><td><b>Max Temperature: $maxtemp</b></td><td><b>Avg Temperature: $avgtemp</b></td></tr>
<tr><td><b>Min Humidity: $minhum</b></td><td><b>Max Humidity: $maxhum</b></td><td><b>Avg Humidity: $avghum</b></td></tr>
</table>                   
EOD;
$pdf->writeHTML($txt1);
$pdf->SetFillColor(255, 255, 215);
if($temp_channel_num_hum==$i)
{
	break;
}
$i++;
}
    $html="";
// Table with rowspans and THEAD
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
 $to_date=date('Y-m-d H:i:s',strtotime( $to_date));
	$this->db->select('Record_Date_Time');
	$this->db->where('scanner_details.Record_Date_Time >=',$from_date);
	$this->db->where('scanner_details.Record_Date_Time <=',$to_date);
	$this->db->where('scanner_details.chamber_seq',$chamber);
	$this->db->where("scanner_details.component_cd BETWEEN 'CH1' AND 'CH14'");
	$this->db->group_by('Record_Date_Time');
	$query=$this->db->get('scanner_details');
	$data=$query->result_array();


for($i=0;$i<count($data);$i++)
{
	 $ch1=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH1','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch2=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH2','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch3=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH3','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch4=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH4','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch5=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH5','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch6=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH6','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch7=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH7','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch8=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH8','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch9=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH9','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch10=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH10','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch11=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH11','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch12=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH12','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch13=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH13','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch14=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH14','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $temp_hum= $this->temprature->get_sv($chamber,$data[$i]['Record_Date_Time']);
	 $ch1=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch1['Temperature_Value'],$ch1['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch2=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch2['Temperature_Value'],$ch2['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch3=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch3['Temperature_Value'],$ch3['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch4=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch4['Temperature_Value'],$ch4['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch5=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch5['Temperature_Value'],$ch5['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch6=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch6['Temperature_Value'],$ch6['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch7=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch7['Temperature_Value'],$ch7['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch8=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch8['Temperature_Value'],$ch8['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch9=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch9['Temperature_Value'],$ch9['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch10=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch10['Temperature_Value'],$ch10['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch11=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch11['Temperature_Value'],$ch11['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch12=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch12['Temperature_Value'],$ch12['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch13=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch13['Temperature_Value'],$ch13['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch14=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch14['Temperature_Value'],$ch14['Humidity_Value'],$tempalarmband,$msHumidityBand);
 $html.='<tr nobr="true">
 <td align="center" style="width:15%">'.date('d-m-Y H:i:00',strtotime($data[$i]['Record_Date_Time'])).'</td>
 <td align="center" style="width:5%">Temp <br> Hum</td>
 	 <td align="center" style="width:5%">'.number_format((float)($temp_hum['Temperature_setpoint']), 1, '.', '').'<br>'.number_format((float)($temp_hum['Humidity_setpoint']), 1, '.', '').'</td>
	 <td align="center" style="width:5%">'.$ch1['Temperature_Value'].' <br> '.$ch1['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch2['Temperature_Value'].' <br> '.$ch2['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch3['Temperature_Value'].' <br> '.$ch3['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch4['Temperature_Value'].' <br> '.$ch4['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch5['Temperature_Value'].' <br> '.$ch5['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch6['Temperature_Value'].' <br> '.$ch6['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch7['Temperature_Value'].' <br> '.$ch7['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch8['Temperature_Value'].' <br> '.$ch8['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch9['Temperature_Value'].' <br> '.$ch9['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch10['Temperature_Value'].' <br> '.$ch10['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch11['Temperature_Value'].' <br> '.$ch11['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch12['Temperature_Value'].' <br> '.$ch12['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch13['Temperature_Value'].' <br> '.$ch13['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch14['Temperature_Value'].' <br> '.$ch14['Humidity_Value'].'</td>

 </tr>';
}

$tbl = <<<EOF
<style>

th{
	border: 1px solid black;
	font-weight:bold;
	background-color: #DCDCDC;
}
td {
  border: 1px solid black;
}
</style>
<table class="first" border="0" cellpadding="4" max-width="100%" >
<thead>

 <tr cellpadding="1">
  <th align="center" style="width:15%">Date/ Time</th>
  <th align="center" style="width:5%"></th>
  <th align="center" style="width:5%">SV</th>
  <th align="center" style="width:5%">CH1</th>
  <th align="center" style="width:5%">CH2</th>
  <th align="center" style="width:5%">CH3</th>
  <th align="center" style="width:5%">CH4</th>
  <th align="center" style="width:5%">CH5</th>
  <th align="center" style="width:5%">CH6</th>
  <th align="center" style="width:5%">CH7</th>
  <th align="center" style="width:5%">CH8</th>
  <th align="center" style="width:5%">CH9</th>
  <th align="center" style="width:5%">CH10</th>
  <th align="center" style="width:5%">CH11</th>
  <th align="center" style="width:5%">CH12</th>
  <th align="center" style="width:5%">CH13</th>
  <th align="center" style="width:5%">CH14</th>

 </tr>
 </thead>
 <tbody>
 $html
 </tbody>
</table>
EOF;

$rem="";

if( $_GET['remark_id']!="")
{
    $rem="";
		 $remark_details=$_GET['remark_id'];
		 
$rem.='
<tr>
<td align="left" colspan="2">'.$remark_details.'</td></tr>
';
$tbl2= <<<EOF
<style>

th{
	border-bottom: 1px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}

table {
	border: 1px solid black;
	border-top: 3px solid black;
}

</style>
<table  cellpadding="3" >
<thead>
 <tr>
  <th>Remark</th>
  <th align="right" style="width:50%;">Username - $get_firstname</th>
 </tr>
</thead>
<tbody>
$rem
</tbody>
</table> 
EOF;
}else
{
   $tbl2= <<<EOF
EOF;
}
$pdf->writeHTML($tbl, true, false, true, false, '');
}
if($temp_channel_num_hum == '16')
{
$fromdate= date('d-m-Y H:i:s',strtotime($from_date));
$todate= date('d-m-Y H:i:s',strtotime($to_date));
  $getstat = $this->common_model->get_records('historydb','',array('historydb_seq'=>'1'),'TRUE');
$get_detailstat = $getstat['status'];

if(flagh == 0)
{
$txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td colspan="2"><b> Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}else{
    $txt=<<<EOD
<hr>
<table border="0" cellpadding="1" cellspacing="1"  >
<tr><td>Note: History Database</td></tr>
<tr><td colspan="2"><b> Scanner Tabuler Offline Analysis Report: $chambercode - $chambername</b></td></tr>
<tr><td colspan="2"><b>Date and Time Format: DD-MM-YYYY HH:mm:ss</b></td></tr>
<tr><td colspan="2"><b>For The Period $fromdate TO $todate</b> </td></tr>
<tr><td colspan="2"><b>Software Version: DAAS4.0</b> </td></tr><br>
</table>
EOD;
}
$pdf->SetHeaderData('', PDF_HEADER_LOGO_WIDTH,$header_title,$txt);
$pdf->SetFont('helvetica', '', 9);
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

$pdf->SetAutoPageBreak(TRUE, 21);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}
$pdf->AddPage();
$pdf->SetFillColor(255, 255, 127);

$pdf->SetFillColor(255, 255, 215);
$tempbands = $this->common_model->get_records('channel_settings',array('temp_alarm_band','humidity_alarm_band'),array('chamber_seq'=>$chamber),'TRUE');		
 $tempalarmband=$tempbands['temp_alarm_band']==null ? "0.0" :$tempbands['temp_alarm_band'];
 $msHumidityBand=$tempbands['humidity_alarm_band']==null ? "0.0" :$tempbands['humidity_alarm_band'];
$tbl1 = <<<EOF
<style>
th{
	border: 0px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}
td {
  border: 0px solid black;
}
</style>
<table class="first" border="0" cellpadding="1" cellspacing="1">
<tr width="99%"><td colspan="2"><b>Temperature in  <sup>o</sup>C, Relative Humidity in %RH, SV: Set Value, Min: Minimum, Max: Maximum, Avg: Average, CH:Channel</b></td></tr>
<tr><td colspan="2"><b>Note : "*" indicates values out of acceptance limit.</b></td></tr>
<tr><td width="40%"><b>Temperature Acceptance Limit ( <sup>o</sup>C):</b>+/- $tempalarmband </td><td width="60%"><b>Humidity Acceptance Limit ( %RH):</b>+/- $msHumidityBand </td></tr>
</table>                   
EOF;
$pdf->writeHTML($tbl1,true, false, true, false, '');
$pdf->SetFillColor(255, 255, 215);
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
$to_date=date('Y-m-d H:i:s',strtotime($to_date));

$header_data=$this->temprature->get_header($chamber,$from_date,$to_date,$temp_channel_num_hum);

$i=1;
foreach ($header_data as $value) {
	
	$channel=$value['CHANNEL'];
	$mintemp=number_format((float)($value['TMINIMUM']), 1, '.', '');//round($value['TMINIMUM'],1);
	$maxtemp=number_format((float)($value['TMAXIMUM']), 1, '.', '');//round($value['TMAXIMUM'],1);
	$avgtemp=number_format((float)($value['TAVERAGE']), 1, '.', '');//round($value['TAVERAGE'],1);
	$minhum=number_format((float)($value['HMINIMUM']), 1, '.', '');//round($value['HMINIMUM'],1);
	$maxhum=number_format((float)($value['HMAXIMUM']), 1, '.', '');//round($value['HMAXIMUM'],1);
	$avghum=number_format((float)($value['HAVERAGE']), 1, '.', '');//round($value['HAVERAGE'],1);
	
$txt1 = <<<EOD
<table cellpadding="1" cellspacing="1"  >
<tr><td colspan="6"><b>$i) For Channel : $channel</b></td></tr>
<tr><td><b>Min Temperature: $mintemp</b></td><td><b>Max Temperature: $maxtemp</b></td><td><b>Avg Temperature: $avgtemp</b></td></tr>
<tr><td><b>Min Humidity: $minhum</b></td><td><b>Max Humidity: $maxhum</b></td><td><b>Avg Humidity: $avghum</b></td></tr>
</table>                   
EOD;
$pdf->writeHTML($txt1);
$pdf->SetFillColor(255, 255, 215);
if($temp_channel_num_hum==$i)
{
	break;
}
$i++;
}

    $html="";
// Table with rowspans and THEAD
$from_date=date('Y-m-d H:i:s',strtotime($from_date));
 $to_date=date('Y-m-d H:i:s',strtotime( $to_date));
	$this->db->select('Record_Date_Time');
	$this->db->where('scanner_details.Record_Date_Time >=',$from_date);
	$this->db->where('scanner_details.Record_Date_Time <=',$to_date);
	$this->db->where('scanner_details.chamber_seq',$chamber);
	$this->db->where("scanner_details.component_cd BETWEEN 'CH1' AND 'CH16'");
	$this->db->group_by('Record_Date_Time');
	$query=$this->db->get('scanner_details');
	$data=$query->result_array();


for($i=0;$i<count($data);$i++)
{
	$ch1=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH1','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch2=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH2','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch3=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH3','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch4=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH4','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch5=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH5','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch6=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH6','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch7=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH7','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch8=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH8','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch9=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH9','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch10=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH10','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch11=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH11','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch12=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH12','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch13=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH13','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch14=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH14','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch15=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH15','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $ch16=$this->common_model->get_records('scanner_details',array('Temperature_Value,Humidity_Value'),array('component_cd'=>'CH16','Record_Date_Time'=>$data[$i]['Record_Date_Time'],'chamber_seq'=>$chamber),TRUE);
	 $temp_hum= $this->temprature->get_sv($chamber,$data[$i]['Record_Date_Time']);
	 $ch1=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch1['Temperature_Value'],$ch1['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch2=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch2['Temperature_Value'],$ch2['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch3=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch3['Temperature_Value'],$ch3['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch4=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch4['Temperature_Value'],$ch4['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch5=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch5['Temperature_Value'],$ch5['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch6=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch6['Temperature_Value'],$ch6['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch7=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch7['Temperature_Value'],$ch7['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch8=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch8['Temperature_Value'],$ch8['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch9=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch9['Temperature_Value'],$ch9['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch10=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch10['Temperature_Value'],$ch10['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch11=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch11['Temperature_Value'],$ch11['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch12=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch12['Temperature_Value'],$ch12['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch13=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch13['Temperature_Value'],$ch13['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch14=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch14['Temperature_Value'],$ch14['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch15=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch15['Temperature_Value'],$ch15['Humidity_Value'],$tempalarmband,$msHumidityBand);
	 $ch16=$this->Checkdata($temp_hum['Temperature_setpoint'],$temp_hum['Humidity_setpoint'],$ch16['Temperature_Value'],$ch16['Humidity_Value'],$tempalarmband,$msHumidityBand);
 $html.='<tr nobr="true">
 <td align="center" style="width:12%">'.date('d-m-Y H:i:00',strtotime($data[$i]['Record_Date_Time'])).'</td>
 <td align="center" style="width:5%">Temp <br> Hum</td>
 	 <td align="center" style="width:5%">'.number_format((float)($temp_hum['Temperature_setpoint']), 1, '.', '').'<br>'.number_format((float)($temp_hum['Humidity_setpoint']), 1, '.', '').'</td>
	 <td align="center" style="width:5%">'.$ch1['Temperature_Value'].' <br> '.$ch1['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch2['Temperature_Value'].' <br> '.$ch2['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch3['Temperature_Value'].' <br> '.$ch3['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch4['Temperature_Value'].' <br> '.$ch4['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch5['Temperature_Value'].' <br> '.$ch5['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch6['Temperature_Value'].' <br> '.$ch6['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch7['Temperature_Value'].' <br> '.$ch7['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch8['Temperature_Value'].' <br> '.$ch8['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch9['Temperature_Value'].' <br> '.$ch9['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch10['Temperature_Value'].' <br> '.$ch10['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch11['Temperature_Value'].' <br> '.$ch11['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch12['Temperature_Value'].' <br> '.$ch12['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch13['Temperature_Value'].' <br> '.$ch13['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch14['Temperature_Value'].' <br> '.$ch14['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch15['Temperature_Value'].' <br> '.$ch16['Humidity_Value'].'</td>
	 <td align="center" style="width:5%">'.$ch15['Temperature_Value'].' <br> '.$ch16['Humidity_Value'].'</td>

 </tr>';
}

$tbl = <<<EOF
<style>

th{
	border: 1px solid black;
	font-weight:bold;
	background-color: #DCDCDC;
}
td {
  border: 1px solid black;
}
</style>
<table class="first" border="0" cellpadding="2"  >
<thead>

 <tr>
  <th align="center" style="width:12%">Date/ Time</th>
  <th align="center" style="width:5%"></th>
  <th align="center" style="width:5%">SV</th>
  <th align="center" style="width:5%">CH1</th>
  <th align="center" style="width:5%">CH2</th>
  <th align="center" style="width:5%">CH3</th>
  <th align="center" style="width:5%">CH4</th>
  <th align="center" style="width:5%">CH5</th>
  <th align="center" style="width:5%">CH6</th>
  <th align="center" style="width:5%">CH7</th>
  <th align="center" style="width:5%">CH8</th>
  <th align="center" style="width:5%">CH9</th>
  <th align="center" style="width:5%">CH10</th>
  <th align="center" style="width:5%">CH11</th>
  <th align="center" style="width:5%">CH12</th>
  <th align="center" style="width:5%">CH13</th>
  <th align="center" style="width:5%">CH14</th>
  <th align="center" style="width:5%">CH15</th>
  <th align="center" style="width:5%">CH16</th>
 </tr>
 </thead>
 <tbody>
 $html
 </tbody>
</table>
EOF;

$rem="";

if( $_GET['remark_id']!="")
{
    $rem="";
		 $remark_details=$_GET['remark_id'];
		 
$rem.='
<tr>
<td align="left" colspan="2">'.$remark_details.'</td></tr>
';
$tbl2= <<<EOF
<style>

th{
	border-bottom: 1px solid black;
	font-weight:bold;
	background-color: #C0C0C0;
}

table {
	border: 1px solid black;
	border-top: 3px solid black;
}

</style>
<table  cellpadding="3" >
<thead>
 <tr>
  <th>Remark</th>
  <th align="right" style="width:50%;">Username - $get_firstname</th>
 </tr>
</thead>
<tbody>
$rem
</tbody>
</table> 
EOF;
}else
{
   $tbl2= <<<EOF

EOF;
}
$pdf->writeHTML($tbl, true, false, true, false, '');
} }
$pdf->lastPage();
$pdf->writeHTML($tbl2, true, false, true, false, '');
// -----------------------------------------------------------------------------
//Close and output PDF document
$date=date('d-m-Y H:i:s');
$path= FCPATH.'assets/report';
ob_end_clean();
$pdf->Output('Scanner_Tabuler_Offline_Analysis_Report_'.$date.'.pdf', 'I');
	}


 function Checkdata($temp_sv,$hum_sv,$temp_val,$hum_val,$tempalarmband,$msHumidityBand)
{
	$tempValue=$temp_val;
	$humValue=$hum_val;
	$tempValuemin=$temp_sv-$tempalarmband;
	$tempValuemax=$temp_sv+$tempalarmband;
	$humedityValuemin=$hum_sv-$msHumidityBand;
	$humedityValuemax=$hum_sv+$msHumidityBand;
	if($tempValue < $tempValuemin || $tempValue > $tempValuemax )
	{
		if($tempValue!="")
		{
			$tempValue=number_format((float)($tempValue), 1, '.', '').'*';
		}else
		{
			$tempValue="--";
		}
		
	}else{
		$tempValue=number_format((float)($tempValue), 1, '.', '');
	}
	if($humValue < $humedityValuemin || $humValue > $humedityValuemax )
	{
		if($humValue!="")
		{
		$humValue=number_format((float)($humValue), 1, '.', '').'*';
	    }
	    else
		{
			$humValue="--";
		}
	}else{
		$humValue=number_format((float)($humValue), 1, '.', '');
	}
	return array('Temperature_Value'=>$tempValue,'Humidity_Value'=>$humValue);
 }
 function Checkdata1($temp_sv,$temp_val,$tempalarmband)
{
	$tempValue=$temp_val;
	$tempValuemin=$temp_sv-$tempalarmband;
	$tempValuemax=$temp_sv+$tempalarmband;

	
	if($tempValue < $tempValuemin || $tempValue > $tempValuemax )
	{
		if($tempValue!="")
		{
			$tempValue=number_format((float)($tempValue), 1, '.', '').'*';
		}else
		{
			$tempValue="--";
		}
		
	}else{
		$tempValue=number_format((float)($tempValue), 1, '.', '');
	}
	
	return array('Temperature_Value'=>$tempValue);
 }

}
 function Checkdata1($temp_sv,$temp_val,$tempalarmband)
{
	$tempValue=$temp_val;
	$tempValuemin=$temp_sv-$tempalarmband;
	$tempValuemax=$temp_sv+$tempalarmband;

	
	if($tempValue < $tempValuemin || $tempValue > $tempValuemax )
	{
		if($tempValue!="")
		{
			$tempValue=number_format((float)($tempValue), 1, '.', '').'*';
		}else
		{
			$tempValue="--";
		}
		
	}else{
		$tempValue=number_format((float)($tempValue), 1, '.', '');
	}
	return array('Temperature_Value'=>$tempValue);
 }

